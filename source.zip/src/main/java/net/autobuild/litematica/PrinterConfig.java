package net.autobuild.litematica;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.registry.Registries;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Quản lý toàn bộ cấu hình của Litematica AutoBuild v2.5.
 * Tự động lưu và tải từ: .minecraft/config/litematica_autobuild.json
 */
public class PrinterConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("litematica_autobuild.json");

    public String menuStyle = "CLASSIC";
    public String activeProfileName = "DonutSMP An Toàn";

    public boolean printerEnabled = false;
    public boolean antiCheatStrictMode = true; // Mặc định BẬT cho Donut SMP (Pre-Rotation + Raycast)
    public boolean strictLayerByLayer = true; // Khóa chặt từng tầng Y: Chưa xong 100% tầng cũ không lên tầng mới
    public boolean autoScaffoldEnabled = true; // Tự động đặt block kê cho khối lơ lửng
    public boolean autoRecycleScaffolds = true; // Tự động phá/thu hồi block kê tạm sau khi đặt xong khối chính
    public boolean autoExcavateWrongBlocks = true; // Tự động đào block đặt sai loại hoặc sai hướng
    public boolean autoSwitchBestTool = true; // Tự động chọn cúp/rìu/xẻng nhanh nhất khi đào
    public boolean autoReplenishInventory = true; // Tự động lấy block từ túi đồ (slot 9..35) xuống Hotbar
    public boolean autoWalkEnabled = false; // Tự động đi bộ theo thuật toán tìm đường A*
    public boolean renderVisualGuides = true; // Vẽ đường Xanh lá (khối tiếp theo) & Xanh nước biển (vị trí đứng)
    public boolean renderHudOverlay = true; // Hiển thị bảng thông tin nhỏ ở góc màn hình

    // 1. Tự động dừng khi hết vật liệu (Hotbar + Inventory không còn block cần xây)
    public boolean autoStopWhenOutOfMaterials = true;

    // 2. Hệ thống Whitelist / Blacklist Block: "BLACKLIST", "WHITELIST", hoặc "NONE"
    public String blockFilterMode = "BLACKLIST";
    public List<String> blacklistedBlocks = new ArrayList<>(List.of(
            "minecraft:tnt",
            "minecraft:bedrock",
            "minecraft:barrier",
            "minecraft:spawner",
            "minecraft:command_block",
            "minecraft:lava",
            "minecraft:fire"
    ));
    public List<String> whitelistedBlocks = new ArrayList<>();

    // 3. Tính năng DonutSMP: Tự động thoát kẹt bằng lệnh /home <số>
    public boolean autoHomeWhenStuck = true;
    public int stuckHomeNumber = 1;
    public int stuckThresholdTicks = 40;

    // 4. Tính năng Nghe Nhạc khi AutoBuild đang chạy (.mp3 / .wav & YouTube)
    public boolean musicEnabled = false;
    public String youtubeLink = "https://www.youtube.com/watch?v=jfKfPfyJRdk";
    public boolean useLocalMusicFolder = false;

    // 5. Thông số tốc độ đặt & Thanh trượt tốc độ xoay góc nhìn mượt (Smooth Rotation Slider)
    public int placeDelayTicks = 2;
    public int inventorySwapCooldownTicks = 3;
    public double maxReachDistance = 4.50;
    public float maxRotationStep = 45.0f; // Chỉnh bằng thanh trượt Slider từ 10.0°/tick (Siêu mượt) -> 180.0°/tick (Tức thời)
    public boolean smoothHumanRotationCurve = true; // Nội suy đường cong giảm tốc mượt (Ease-Out) chống Anti-Cheat
    public int layerScanRadius = 48;

    public static PrinterConfig load() {
        if (Files.exists(CONFIG_PATH)) {
            try (Reader reader = Files.newBufferedReader(CONFIG_PATH)) {
                PrinterConfig loaded = GSON.fromJson(reader, PrinterConfig.class);
                if (loaded != null) {
                    loaded.sanitize();
                    return loaded;
                }
            } catch (IOException ignored) {
            }
        }
        PrinterConfig defaults = new PrinterConfig();
        defaults.sanitize();
        defaults.save();
        return defaults;
    }

    public void sanitize() {
        if (menuStyle == null || menuStyle.isBlank()) {
            menuStyle = "CLASSIC";
        }
        if (activeProfileName == null || activeProfileName.isBlank()) {
            activeProfileName = "DonutSMP An Toàn";
        }
        if (blockFilterMode == null || blockFilterMode.isBlank()) {
            blockFilterMode = "BLACKLIST";
        }
        if (blacklistedBlocks == null) {
            blacklistedBlocks = new ArrayList<>(List.of("minecraft:tnt", "minecraft:bedrock", "minecraft:barrier"));
        }
        if (whitelistedBlocks == null) {
            whitelistedBlocks = new ArrayList<>();
        }
        if (maxRotationStep < 10.0f) {
            maxRotationStep = 10.0f;
        } else if (maxRotationStep > 180.0f) {
            maxRotationStep = 180.0f;
        }
        if (maxReachDistance < 3.5) {
            maxReachDistance = 4.50;
        }
        if (layerScanRadius < 24) {
            layerScanRadius = 48;
        }
        if (stuckHomeNumber < 1) {
            stuckHomeNumber = 1;
        }
        if (stuckThresholdTicks < 15) {
            stuckThresholdTicks = 40;
        }
        if (youtubeLink == null || youtubeLink.isBlank()) {
            youtubeLink = "https://www.youtube.com/watch?v=jfKfPfyJRdk";
        }
    }

    /**
     * Kiểm tra một Block trong bản vẽ có được phép tự động đặt hay không dựa theo Whitelist / Blacklist.
     */
    public boolean isBlockAllowed(Block block) {
        if (block == null) {
            return false;
        }
        if ("NONE".equalsIgnoreCase(blockFilterMode)) {
            return true;
        }
        String fullId = Registries.BLOCK.getId(block).toString().toLowerCase(Locale.ROOT);
        String shortId = fullId.startsWith("minecraft:") ? fullId.substring("minecraft:".length()) : fullId;

        if ("WHITELIST".equalsIgnoreCase(blockFilterMode)) {
            return matchesList(whitelistedBlocks, fullId, shortId);
        }
        // Mặc định BLACKLIST: Chặn nếu nằm trong danh sách đen
        return !matchesList(blacklistedBlocks, fullId, shortId);
    }

    private static boolean matchesList(List<String> list, String fullId, String shortId) {
        if (list == null || list.isEmpty()) {
            return false;
        }
        for (String entry : list) {
            if (entry == null) continue;
            String clean = entry.trim().toLowerCase(Locale.ROOT);
            if (clean.equals(fullId) || clean.equals(shortId) || ("minecraft:" + clean).equals(fullId)) {
                return true;
            }
        }
        return false;
    }

    public static String normalizeBlockId(String raw) {
        if (raw == null) return "";
        String clean = raw.trim().toLowerCase(Locale.ROOT);
        if (clean.isEmpty()) return "";
        if (!clean.contains(":")) {
            clean = "minecraft:" + clean;
        }
        return clean;
    }

    public void copySettingsFrom(PrinterConfig other) {
        if (other == null) return;
        this.antiCheatStrictMode = other.antiCheatStrictMode;
        this.strictLayerByLayer = other.strictLayerByLayer;
        this.autoScaffoldEnabled = other.autoScaffoldEnabled;
        this.autoRecycleScaffolds = other.autoRecycleScaffolds;
        this.autoExcavateWrongBlocks = other.autoExcavateWrongBlocks;
        this.autoSwitchBestTool = other.autoSwitchBestTool;
        this.autoReplenishInventory = other.autoReplenishInventory;
        this.autoWalkEnabled = other.autoWalkEnabled;
        this.renderVisualGuides = other.renderVisualGuides;
        this.renderHudOverlay = other.renderHudOverlay;
        this.autoStopWhenOutOfMaterials = other.autoStopWhenOutOfMaterials;
        this.blockFilterMode = other.blockFilterMode;
        this.blacklistedBlocks = new ArrayList<>(other.blacklistedBlocks);
        this.whitelistedBlocks = new ArrayList<>(other.whitelistedBlocks);
        this.autoHomeWhenStuck = other.autoHomeWhenStuck;
        this.stuckHomeNumber = other.stuckHomeNumber;
        this.stuckThresholdTicks = other.stuckThresholdTicks;
        this.placeDelayTicks = other.placeDelayTicks;
        this.inventorySwapCooldownTicks = other.inventorySwapCooldownTicks;
        this.maxReachDistance = other.maxReachDistance;
        this.maxRotationStep = other.maxRotationStep;
        this.smoothHumanRotationCurve = other.smoothHumanRotationCurve;
        this.layerScanRadius = other.layerScanRadius;
        this.sanitize();
    }

    public void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(CONFIG_PATH)) {
                GSON.toJson(this, writer);
            }
        } catch (IOException ignored) {
        }
    }
}
