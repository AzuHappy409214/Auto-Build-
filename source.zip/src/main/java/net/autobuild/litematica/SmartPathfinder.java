package net.autobuild.litematica;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;

/**
 * Bộ tìm vị trí đứng thông minh (Vantage Point), Tìm đường A* & Tự Động Thoát Kẹt DonutSMP (/home <số>).
 */
public class SmartPathfinder {

    private BlockPos nextTargetBlockPos = null;
    private BlockPos nextStandPos = null;
    private List<BlockPos> currentPath = new ArrayList<>();
    private int pathRecalcCooldown = 0;

    private Vec3d lastPlayerPos = Vec3d.ZERO;
    private int movementStuckTicks = 0;
    private int hitboxTrappedTicks = 0;
    private int homeCommandCooldownTicks = 0;

    private record PathNode(BlockPos pos, double gCost, double fCost) {}

    public void reset(MinecraftClient client, PrinterConfig config) {
        nextTargetBlockPos = null;
        nextStandPos = null;
        currentPath.clear();
        movementStuckTicks = 0;
        hitboxTrappedTicks = 0;
        releaseWalkKeys(client, config);
    }

    public BlockPos getNextTargetBlockPos() {
        return nextTargetBlockPos;
    }

    public BlockPos getNextStandPos() {
        return nextStandPos;
    }

    public List<BlockPos> getCurrentPath() {
        return currentPath;
    }

    public void tickStuckWatchdog(MinecraftClient client, World schematicWorld, PrinterConfig config, BlockPos hitboxBlockedPos) {
        if (homeCommandCooldownTicks > 0) {
            homeCommandCooldownTicks--;
        }
        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        if (player == null || world == null || !config.printerEnabled) {
            hitboxTrappedTicks = 0;
            return;
        }

        boolean physicallySuffocating = isPlayerSuffocatingInSolidBlock(world, player);
        boolean boxedIn = isPlayerTrappedIn1x1Box(world, player);
        boolean hitboxWedged = (hitboxBlockedPos != null && player.getEyePos().squaredDistanceTo(lastPlayerPos) < 0.0025);

        if (physicallySuffocating || boxedIn || hitboxWedged) {
            hitboxTrappedTicks++;
            int limit = physicallySuffocating ? 12 : Math.max(20, config.stuckThresholdTicks / 2);
            if (config.autoHomeWhenStuck && hitboxTrappedTicks >= limit && homeCommandCooldownTicks == 0) {
                String reason = physicallySuffocating ? "Kẹt trong Block" : (boxedIn ? "Bị bít kín 4 phía" : "Vướng Hitbox");
                executeDonutHomeCommand(client, config, reason);
                hitboxTrappedTicks = 0;
                movementStuckTicks = 0;
            }
        } else {
            hitboxTrappedTicks = 0;
        }
    }

    public void executeDonutHomeCommand(MinecraftClient client, PrinterConfig config, String reason) {
        if (client == null || client.player == null || client.player.networkHandler == null) {
            return;
        }
        int homeIndex = Math.max(1, config.stuckHomeNumber);
        String commandWithoutSlash = "home " + homeIndex;

        releaseWalkKeys(client, config);
        client.player.networkHandler.sendChatCommand(commandWithoutSlash);
        homeCommandCooldownTicks = 120;

        client.player.sendMessage(
                Text.literal("§8[§bLitematica-AutoBuild§8] §ePhát hiện kẹt (" + reason + ") §7→ §aĐã dùng lệnh §6/" + commandWithoutSlash + "§a!"),
                true
        );
    }

    private boolean isPlayerSuffocatingInSolidBlock(ClientWorld world, ClientPlayerEntity player) {
        BlockPos feet = player.getBlockPos();
        BlockPos head = feet.up();
        Box shrunkBox = player.getBoundingBox().contract(0.08, 0.05, 0.08);

        BlockState feetState = world.getBlockState(feet);
        if (!feetState.isAir() && !feetState.getCollisionShape(world, feet).isEmpty()) {
            Box shapeBox = feetState.getCollisionShape(world, feet).getBoundingBox().offset(feet);
            if (shrunkBox.intersects(shapeBox)) {
                return true;
            }
        }

        BlockState headState = world.getBlockState(head);
        if (!headState.isAir() && !headState.getCollisionShape(world, head).isEmpty()) {
            Box shapeBox = headState.getCollisionShape(world, head).getBoundingBox().offset(head);
            if (shrunkBox.intersects(shapeBox)) {
                return true;
            }
        }
        return false;
    }

    private boolean isPlayerTrappedIn1x1Box(ClientWorld world, ClientPlayerEntity player) {
        BlockPos feet = player.getBlockPos();
        int blockedSides = 0;
        for (Direction dir : Direction.Type.HORIZONTAL) {
            BlockPos sideFeet = feet.offset(dir);
            BlockPos sideHead = sideFeet.up();
            boolean feetBlocked = !world.getBlockState(sideFeet).getCollisionShape(world, sideFeet).isEmpty();
            boolean headBlocked = !world.getBlockState(sideHead).getCollisionShape(world, sideHead).isEmpty();
            boolean jumpBlocked = !world.getBlockState(sideHead.up()).getCollisionShape(world, sideHead.up()).isEmpty()
                    || !world.getBlockState(feet.up(2)).getCollisionShape(world, feet.up(2)).isEmpty();
            if ((feetBlocked && headBlocked) || (feetBlocked && jumpBlocked)) {
                blockedSides++;
            }
        }
        return blockedSides == 4;
    }

    public void updateVisualTargetOnly(MinecraftClient client, BlockPos activePlacementTarget) {
        if (activePlacementTarget != null) {
            this.nextTargetBlockPos = activePlacementTarget;
        }
        releaseWalkKeys(client, null);
    }

    public void stepBackFromBlockedTarget(
            MinecraftClient client,
            World schematicWorld,
            BlockPos blockedPos,
            PrinterConfig config
    ) {
        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        if (player == null || world == null || blockedPos == null) {
            return;
        }

        this.nextTargetBlockPos = blockedPos;
        BlockPos safeSpot = computeOptimalStandingSpotForTarget(world, schematicWorld, player.getBlockPos(), blockedPos);
        if (safeSpot != null) {
            this.nextStandPos = safeSpot;
        }

        double dx = player.getX() - (blockedPos.getX() + 0.5);
        double dz = player.getZ() - (blockedPos.getZ() + 0.5);
        if (Math.abs(dx) < 0.05 && Math.abs(dz) < 0.05) {
            dx = 1.0;
        }

        if (config.autoWalkEnabled) {
            float awayYaw = (float) (MathHelper.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
            PlacementEngine.applySmoothRotation(player, awayYaw, player.getPitch(), config.maxRotationStep, config.smoothHumanRotationCurve);
            client.options.forwardKey.setPressed(true);
            client.options.backKey.setPressed(false);
        }
        lastPlayerPos = player.getEyePos();
    }

    public void updateTargetsAndWalk(
            MinecraftClient client,
            World schematicWorld,
            PrinterConfig config,
            InventoryManager inventoryManager,
            SchematicAnalyzer analyzer
    ) {
        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        if (player == null || world == null || schematicWorld == null) {
            return;
        }

        if (pathRecalcCooldown > 0) {
            pathRecalcCooldown--;
        }

        Integer activeLayerY = config.strictLayerByLayer ? analyzer.getActiveLayerY() : null;

        if (pathRecalcCooldown == 0 || nextStandPos == null || nextTargetBlockPos == null
                || !world.getBlockState(nextTargetBlockPos).isReplaceable()
                || (activeLayerY != null && nextTargetBlockPos.getY() != activeLayerY)) {
            findBestNextBlockAndVantagePoint(client, schematicWorld, config, inventoryManager, activeLayerY);
            if (nextStandPos != null && !nextStandPos.equals(player.getBlockPos())) {
                this.currentPath = computeAStarPath(world, schematicWorld, player.getBlockPos(), nextStandPos, 320);
            } else {
                this.currentPath.clear();
            }
            pathRecalcCooldown = 8;
        }

        if (!config.autoWalkEnabled) {
            releaseWalkKeys(client, config);
            return;
        }

        if (nextTargetBlockPos != null && isPlayerIntersectingBlock(player, nextTargetBlockPos)) {
            stepBackFromBlockedTarget(client, schematicWorld, nextTargetBlockPos, config);
            return;
        }

        if (nextStandPos == null) {
            releaseWalkKeys(client, config);
            return;
        }

        double distSqToStand = player.getEyePos().subtract(0, player.getStandingEyeHeight(), 0)
                .squaredDistanceTo(new Vec3d(nextStandPos.getX() + 0.5, nextStandPos.getY(), nextStandPos.getZ() + 0.5));
        if (distSqToStand <= 0.65) {
            movementStuckTicks = 0;
            releaseWalkKeys(client, config);
            return;
        }

        BlockPos waypoint = nextStandPos;
        while (!currentPath.isEmpty() && player.getBlockPos().getSquaredDistance(currentPath.get(0)) <= 0.9) {
            currentPath.remove(0);
        }
        if (!currentPath.isEmpty()) {
            waypoint = currentPath.get(0);
        }

        if (player.getEyePos().squaredDistanceTo(lastPlayerPos) < 0.0025) {
            movementStuckTicks++;
            if (config.autoHomeWhenStuck && movementStuckTicks >= config.stuckThresholdTicks && homeCommandCooldownTicks == 0) {
                executeDonutHomeCommand(client, config, "Kẹt đường đi quá " + (config.stuckThresholdTicks / 20.0f) + "s");
                movementStuckTicks = 0;
                pathRecalcCooldown = 0;
                return;
            }
            if (movementStuckTicks % 15 == 0) {
                pathRecalcCooldown = 0;
            }
        } else {
            movementStuckTicks = 0;
        }
        lastPlayerPos = player.getEyePos();

        double dx = (waypoint.getX() + 0.5) - player.getX();
        double dz = (waypoint.getZ() + 0.5) - player.getZ();
        float targetYaw = (float) (MathHelper.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;

        PlacementEngine.applySmoothRotation(player, targetYaw, player.getPitch(), config.maxRotationStep, config.smoothHumanRotationCurve);
        client.options.forwardKey.setPressed(true);
        client.options.backKey.setPressed(false);

        boolean needJump = (waypoint.getY() > player.getBlockPos().getY() && player.isOnGround())
                || (player.horizontalCollision && player.isOnGround());
        client.options.jumpKey.setPressed(needJump);

        boolean nearEdge = world.getBlockState(player.getBlockPos().down()).isAir();
        client.options.sneakKey.setPressed(nearEdge && player.isOnGround());
    }

    public static boolean isPlayerIntersectingBlock(ClientPlayerEntity player, BlockPos pos) {
        Box blockBox = new Box(
                pos.getX(), pos.getY(), pos.getZ(),
                pos.getX() + 1.0, pos.getY() + 1.0, pos.getZ() + 1.0
        );
        return player.getBoundingBox().expand(0.08).intersects(blockBox);
    }

    private void findBestNextBlockAndVantagePoint(
            MinecraftClient client,
            World schematicWorld,
            PrinterConfig config,
            InventoryManager inventoryManager,
            Integer lockedLayerY
    ) {
        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        BlockPos playerPos = player.getBlockPos();

        int searchRadius = Math.max(18, Math.min(config.layerScanRadius, 48));
        int minDy = (lockedLayerY != null) ? (lockedLayerY - playerPos.getY()) : -8;
        int maxDy = (lockedLayerY != null) ? (lockedLayerY - playerPos.getY()) : 8;

        BlockPos bestTargetBlock = null;
        BlockPos bestVantage = null;
        double bestScore = Double.MAX_VALUE;

        for (int dy = minDy; dy <= maxDy; dy++) {
            int y = playerPos.getY() + dy;
            if (lockedLayerY != null && y != lockedLayerY) {
                continue;
            }

            for (int dx = -searchRadius; dx <= searchRadius; dx++) {
                for (int dz = -searchRadius; dz <= searchRadius; dz++) {
                    BlockPos pos = new BlockPos(playerPos.getX() + dx, y, playerPos.getZ() + dz);
                    if (!LitematicaBridge.isWithinLayerRange(pos)) {
                        continue;
                    }

                    BlockState schemState = schematicWorld.getBlockState(pos);
                    if (schemState.isAir() || !schemState.getFluidState().isEmpty()) {
                        continue;
                    }

                    if (!config.isBlockAllowed(schemState.getBlock())) {
                        continue;
                    }

                    if (!world.getBlockState(pos).isReplaceable()) {
                        continue;
                    }

                    Item item = schemState.getBlock().asItem();
                    if (item == Items.AIR || !inventoryManager.hasItemAvailable(player, item)) {
                        continue;
                    }

                    boolean hasSupport = hasAnySolidNeighbor(world, pos);
                    double distSq = playerPos.getSquaredDistance(pos);
                    double score = distSq + (hasSupport ? 0.0 : 20.0);

                    if (score < bestScore) {
                        BlockPos vantage = computeOptimalStandingSpotForTarget(world, schematicWorld, playerPos, pos);
                        if (vantage != null) {
                            bestScore = score;
                            bestTargetBlock = pos;
                            bestVantage = vantage;
                        }
                    }
                }
            }
        }

        this.nextTargetBlockPos = bestTargetBlock;
        this.nextStandPos = bestVantage;
    }

    public static BlockPos computeOptimalStandingSpotForTarget(
            ClientWorld world,
            World schematicWorld,
            BlockPos playerPos,
            BlockPos targetBlock
    ) {
        BlockPos bestSpot = null;
        double bestScore = Double.MAX_VALUE;

        for (int dy = -2; dy <= 1; dy++) {
            for (int dx = -3; dx <= 3; dx++) {
                for (int dz = -3; dz <= 3; dz++) {
                    if (dx == 0 && dz == 0) {
                        continue;
                    }

                    BlockPos spot = targetBlock.add(dx, dy, dz);
                    double horizDistSq = dx * dx + dz * dz;
                    if (horizDistSq < 2.0 || horizDistSq > 13.0) {
                        continue;
                    }

                    double eyeToTargetSq = new Vec3d(spot.getX() + 0.5, spot.getY() + 1.62, spot.getZ() + 0.5)
                            .squaredDistanceTo(Vec3d.ofCenter(targetBlock));
                    if (eyeToTargetSq > 16.5) {
                        continue;
                    }

                    if (!isSafeStandingSpot(world, schematicWorld, spot)) {
                        continue;
                    }

                    double distToPlayer = Math.sqrt(playerPos.getSquaredDistance(spot));
                    double idealDistPenalty = Math.abs(horizDistSq - 5.0) * 0.6;
                    double score = distToPlayer + idealDistPenalty;

                    if (score < bestScore) {
                        bestScore = score;
                        bestSpot = spot;
                    }
                }
            }
        }
        return bestSpot;
    }

    public static boolean isSafeStandingSpot(ClientWorld world, World schematicWorld, BlockPos footPos) {
        BlockState floor = world.getBlockState(footPos.down());
        if (floor.isAir() || floor.isReplaceable()
                || floor.isOf(Blocks.LAVA) || floor.isOf(Blocks.FIRE)
                || floor.isOf(Blocks.MAGMA_BLOCK) || floor.isOf(Blocks.CACTUS)) {
            return false;
        }

        BlockState feet = world.getBlockState(footPos);
        BlockState head = world.getBlockState(footPos.up());
        if (!feet.getCollisionShape(world, footPos).isEmpty()
                || !head.getCollisionShape(world, footPos.up()).isEmpty()) {
            return false;
        }
        if (feet.isOf(Blocks.LAVA) || feet.isOf(Blocks.FIRE) || head.isOf(Blocks.LAVA)) {
            return false;
        }

        if (schematicWorld != null) {
            BlockState schemAtFeet = schematicWorld.getBlockState(footPos);
            if (!schemAtFeet.isAir() && schemAtFeet.getFluidState().isEmpty()) {
                return false;
            }
        }

        return true;
    }

    private boolean hasAnySolidNeighbor(ClientWorld world, BlockPos pos) {
        for (Direction dir : Direction.values()) {
            BlockState neighbor = world.getBlockState(pos.offset(dir));
            if (!neighbor.isAir() && !neighbor.isReplaceable()) {
                return true;
            }
        }
        return false;
    }

    private List<BlockPos> computeAStarPath(
            ClientWorld world,
            World schematicWorld,
            BlockPos start,
            BlockPos goal,
            int maxIterations
    ) {
        PriorityQueue<PathNode> openSet = new PriorityQueue<>(Comparator.comparingDouble(PathNode::fCost));
        Map<BlockPos, BlockPos> cameFrom = new HashMap<>();
        Map<BlockPos, Double> gScore = new HashMap<>();
        Set<BlockPos> closedSet = new HashSet<>();

        gScore.put(start, 0.0);
        openSet.add(new PathNode(start, 0.0, heuristic(start, goal)));

        int iterations = 0;
        BlockPos closestNode = start;
        double closestHeuristic = heuristic(start, goal);

        while (!openSet.isEmpty() && iterations++ < maxIterations) {
            PathNode current = openSet.poll();
            BlockPos currentPos = current.pos();

            if (currentPos.equals(goal) || currentPos.getSquaredDistance(goal) <= 1.2) {
                return reconstructPath(cameFrom, currentPos);
            }

            if (!closedSet.add(currentPos)) {
                continue;
            }

            double h = heuristic(currentPos, goal);
            if (h < closestHeuristic) {
                closestHeuristic = h;
                closestNode = currentPos;
            }

            for (Direction dir : Direction.Type.HORIZONTAL) {
                for (int dy = -1; dy <= 1; dy++) {
                    BlockPos neighbor = currentPos.offset(dir).add(0, dy, 0);
                    if (closedSet.contains(neighbor)) {
                        continue;
                    }
                    if (!isSafeStandingSpot(world, null, neighbor)) {
                        continue;
                    }
                    if (dy == 1 && !world.getBlockState(currentPos.up(2)).getCollisionShape(world, currentPos.up(2)).isEmpty()) {
                        continue;
                    }

                    double stepCost = 1.0 + (dy == 1 ? 0.45 : (dy == -1 ? 0.25 : 0.0));
                    if (schematicWorld != null && !schematicWorld.getBlockState(neighbor).isAir()) {
                        stepCost += 1.5;
                    }

                    double tentativeG = gScore.getOrDefault(currentPos, Double.MAX_VALUE) + stepCost;
                    if (tentativeG < gScore.getOrDefault(neighbor, Double.MAX_VALUE)) {
                        cameFrom.put(neighbor, currentPos);
                        gScore.put(neighbor, tentativeG);
                        openSet.add(new PathNode(neighbor, tentativeG, tentativeG + heuristic(neighbor, goal)));
                    }
                }
            }
        }

        return reconstructPath(cameFrom, closestNode);
    }

    private double heuristic(BlockPos a, BlockPos b) {
        return Math.sqrt(a.getSquaredDistance(b));
    }

    private List<BlockPos> reconstructPath(Map<BlockPos, BlockPos> cameFrom, BlockPos current) {
        List<BlockPos> path = new ArrayList<>();
        BlockPos cursor = current;
        while (cameFrom.containsKey(cursor)) {
            path.add(cursor);
            cursor = cameFrom.get(cursor);
        }
        Collections.reverse(path);
        return path;
    }

    public void releaseWalkKeys(MinecraftClient client, PrinterConfig config) {
        if (client != null && client.options != null) {
            client.options.forwardKey.setPressed(false);
            client.options.backKey.setPressed(false);
            client.options.jumpKey.setPressed(false);
            client.options.sneakKey.setPressed(false);
        }
    }
}
