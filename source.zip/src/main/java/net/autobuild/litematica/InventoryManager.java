package net.autobuild.litematica;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FallingBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

import java.util.List;

/**
 * Quản lý việc chọn ô Hotbar, tự động nạp block từ Balo (slot 9..35) xuống Hotbar:
 * - Bổ sung hàm hasItemReadyForImmediateUse(): Nếu đang trong thời gian chờ swapCooldown mà vật phẩm
 *   chưa nằm trên Hotbar, không cho phép PlacementEngine xoay đầu sớm (tránh xoay đầu xong không đặt được).
 */
public class InventoryManager {

    private static final List<Item> PREFERRED_SCAFFOLD_ITEMS = List.of(
            Items.DIRT,
            Items.COBBLESTONE,
            Items.NETHERRACK,
            Items.COBBLED_DEEPSLATE,
            Items.STONE,
            Items.ANDESITE,
            Items.DIORITE,
            Items.GRANITE,
            Items.OAK_PLANKS,
            Items.SPRUCE_PLANKS,
            Items.BIRCH_PLANKS,
            Items.SCAFFOLDING
    );

    private int swapCooldown = 0;

    public void tick() {
        if (swapCooldown > 0) {
            swapCooldown--;
        }
    }

    public boolean hasItemAvailable(ClientPlayerEntity player, Item item) {
        if (item == null || item == Items.AIR) {
            return false;
        }
        if (player.isCreative()) {
            return true;
        }
        if (player.getOffHandStack().isOf(item)) {
            return true;
        }
        PlayerInventory inventory = player.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty() && stack.isOf(item)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Kiểm tra xem vật phẩm có sẵn sàng để trang bị ngay trong tick này không (tránh lỗi xoay đầu khi đang kẹt swapCooldown).
     */
    public boolean hasItemReadyForImmediateUse(ClientPlayerEntity player, Item item, PrinterConfig config) {
        if (item == null || item == Items.AIR) {
            return false;
        }
        if (player.isCreative() || player.getOffHandStack().isOf(item) || player.getMainHandStack().isOf(item)) {
            return true;
        }
        PlayerInventory inventory = player.getInventory();
        for (int i = 0; i < 9; i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty() && stack.isOf(item)) {
                return true;
            }
        }
        if (!config.autoReplenishInventory || swapCooldown > 0) {
            return false;
        }
        for (int i = 9; i < 36; i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty() && stack.isOf(item)) {
                return true;
            }
        }
        return false;
    }

    public Item findAvailableScaffoldItem(ClientPlayerEntity player) {
        if (player.isCreative()) {
            return Items.DIRT;
        }
        PlayerInventory inventory = player.getInventory();

        for (Item preferred : PREFERRED_SCAFFOLD_ITEMS) {
            for (int i = 0; i < 36; i++) {
                ItemStack stack = inventory.getStack(i);
                if (!stack.isEmpty() && stack.isOf(preferred)) {
                    return preferred;
                }
            }
        }

        for (int i = 0; i < 36; i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty() && stack.getItem() instanceof BlockItem blockItem) {
                Block block = blockItem.getBlock();
                if (!(block instanceof FallingBlock)
                        && block != Blocks.TNT
                        && block.getDefaultState().isFullCube(player.getEntityWorld(), player.getBlockPos())) {
                    return stack.getItem();
                }
            }
        }
        return null;
    }

    public boolean equipItemForPlacement(MinecraftClient client, Item requiredItem, PrinterConfig config) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null || requiredItem == null) {
            return false;
        }
        PlayerInventory inventory = player.getInventory();

        if (player.getMainHandStack().isOf(requiredItem) || player.getOffHandStack().isOf(requiredItem)) {
            return true;
        }

        for (int i = 0; i < 9; i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty() && stack.isOf(requiredItem)) {
                inventory.setSelectedSlot(i);
                return true;
            }
        }

        if (player.isCreative()) {
            int slot = inventory.getSelectedSlot();
            ItemStack creativeStack = new ItemStack(requiredItem, 64);
            inventory.setStack(slot, creativeStack);
            client.interactionManager.clickCreativeStack(creativeStack, 36 + slot);
            return true;
        }

        if (!config.autoReplenishInventory || swapCooldown > 0) {
            return false;
        }

        int backpackSlot = -1;
        for (int i = 9; i < 36; i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty() && stack.isOf(requiredItem)) {
                backpackSlot = i;
                break;
            }
        }

        if (backpackSlot != -1) {
            int targetHotbarSlot = inventory.getSelectedSlot();
            for (int i = 0; i < 9; i++) {
                if (inventory.getStack(i).isEmpty()) {
                    targetHotbarSlot = i;
                    break;
                }
            }

            client.interactionManager.clickSlot(
                    player.playerScreenHandler.syncId,
                    backpackSlot,
                    targetHotbarSlot,
                    SlotActionType.SWAP,
                    player
            );
            inventory.setSelectedSlot(targetHotbarSlot);
            swapCooldown = config.inventorySwapCooldownTicks;
            return true;
        }

        return false;
    }

    public void selectBestMiningTool(ClientPlayerEntity player, BlockState targetState) {
        PlayerInventory inventory = player.getInventory();
        int bestSlot = inventory.getSelectedSlot();
        float bestSpeed = player.getMainHandStack().getMiningSpeedMultiplier(targetState);

        for (int i = 0; i < 9; i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty()) {
                float speed = stack.getMiningSpeedMultiplier(targetState);
                if (speed > bestSpeed) {
                    bestSpeed = speed;
                    bestSlot = i;
                }
            }
        }

        if (bestSlot != inventory.getSelectedSlot()) {
            inventory.setSelectedSlot(bestSlot);
        }
    }
}
