package net.autobuild.litematica;

import net.minecraft.block.AbstractSignBlock;
import net.minecraft.block.AmethystClusterBlock;
import net.minecraft.block.AnvilBlock;
import net.minecraft.block.BarrelBlock;
import net.minecraft.block.BellBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.CocoaBlock;
import net.minecraft.block.ComparatorBlock;
import net.minecraft.block.DispenserBlock;
import net.minecraft.block.DropperBlock;
import net.minecraft.block.EndRodBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.HopperBlock;
import net.minecraft.block.LadderBlock;
import net.minecraft.block.LightningRodBlock;
import net.minecraft.block.ObserverBlock;
import net.minecraft.block.PillarBlock;
import net.minecraft.block.PistonBlock;
import net.minecraft.block.RepeaterBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.block.TripwireHookBlock;
import net.minecraft.block.WallBannerBlock;
import net.minecraft.block.WallMountedBlock;
import net.minecraft.block.WallTorchBlock;
import net.minecraft.block.enums.BlockFace;
import net.minecraft.block.enums.BlockHalf;
import net.minecraft.block.enums.SlabType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Bộ xử lý đặt block thông minh v2.6 (Khắc phục triệt để 100% lỗi Đặt Sai Hướng & Lắc Đầu Xoay Vòng Vòng):
 *
 * 1. TÁCH PHA XOAY (START_CLIENT_TICK) VÀ PHA ĐẶT BLOCK (END_CLIENT_TICK):
 *    - Trong Minecraft, ClientPlayerEntity.tick() -> sendMovementPackets() chạy ở GIỮA tick (sau START_CLIENT_TICK
 *      và trước END_CLIENT_TICK).
 *    - Bản cũ gọi interactBlock() ngay trong START_CLIENT_TICK khiến gói tin đặt block bay lên Server TRƯỚC khi
 *      gói tin góc nhìn mới được gửi đi -> Server luôn dùng góc Yaw/Pitch của tick cũ làm đặt sai hướng!
 *    - Bản v2.6 xoay đầu trong START_CLIENT_TICK, đợi Minecraft tự động gửi gói tin góc nhìn chuẩn trong
 *      ClientPlayerEntity.sendMovementPackets(), rồi mới gọi interactBlock() trong END_CLIENT_TICK!
 *
 * 2. CHỐNG LẮC ĐẦU XOAY VÒNG VÒNG KHI SERVER HỦY BLOCK (GHOST ROLLBACK PROTECTION):
 *    - Trên các server như DonutSMP, khi 1 mặt đặt bị khuất hoặc bị Anti-Cheat từ chối, client vẫn trả về
 *      ActionResult.SUCCESS rồi 2-4 ticks sau server mới trả gói tin biến block đó về lại AIR.
 *    - Bản v2.6 thêm recentAttemptCooldowns (10 ticks) cho mỗi ô vừa đặt + ghi nhớ các mặt clickSide đã thử
 *      (attemptedSidesPerPos). Nếu sau 10 ticks ô đó vẫn là AIR (bị server hủy), mod tự động đổi sang mặt tựa
 *      khác hoặc tạm khóa ô đó 80 ticks (failedTargetCooldowns) để xây tiếp các ô xung quanh, tuyệt đối không
 *      bao giờ xoay đầu lặp đi lặp lại tại 1 ô!
 *
 * 3. HỖ TRỢ ĐẦY ĐỦ DOUBLE SLAB & MỌI BLOCK CÓ HƯỚNG VANILLA 1.21.11:
 *    - Hỗ trợ ghép tấm Slab thứ 2 thành SlabType.DOUBLE mà không bị phá nhầm.
 *    - Tính chuẩn xác 100% góc đặt cho Stairs, Slab, Log/Pillar, Hopper, Repeater, Comparator, Observer,
 *      Piston, Dispenser, Dropper, Barrel, Furnace, Chest, Anvil, Trapdoor, Button/Lever, Ladder, EndRod.
 */
public class PlacementEngine {

    public record PlacementTask(
            BlockPos targetPos,
            BlockPos neighborPos,
            Direction clickSide,
            Vec3d hitVec,
            float requiredYaw,
            float requiredPitch,
            Item requiredItem,
            BlockState schematicState,
            boolean isTemporaryScaffold
    ) {}

    private PlacementTask pendingTask = null;
    private PlacementTask readyForEndTickTask = null;
    private int pendingWaitTicks = 0;
    private BlockPos currentHighlightedTarget = null;
    private BlockPos blockedByHitboxPos = null;
    private BlockPos lastPlayerBlockPos = null;
    private String currentActionStatus = "Đang quét bản vẽ...";

    // Bộ nhớ chống xoay đầu lặp lại khi Server từ chối đặt block (Ghost Rollback Protection)
    private final Map<BlockPos, Integer> recentAttemptCooldowns = new HashMap<>();
    private final Map<BlockPos, Integer> targetFailCounts = new HashMap<>();
    private final Map<BlockPos, Integer> failedTargetCooldowns = new HashMap<>();
    private final Map<BlockPos, Set<Direction>> attemptedSidesPerPos = new HashMap<>();

    public void reset() {
        pendingTask = null;
        readyForEndTickTask = null;
        pendingWaitTicks = 0;
        currentHighlightedTarget = null;
        blockedByHitboxPos = null;
        lastPlayerBlockPos = null;
        recentAttemptCooldowns.clear();
        targetFailCounts.clear();
        failedTargetCooldowns.clear();
        attemptedSidesPerPos.clear();
        currentActionStatus = "Đã dừng";
    }

    public void tickCooldownMap(ClientPlayerEntity player) {
        if (player != null) {
            BlockPos currentPos = player.getBlockPos();
            if (lastPlayerBlockPos != null && !lastPlayerBlockPos.equals(currentPos)) {
                // Khi người chơi bước sang ô mới, góc nhìn thay đổi nên mở khóa lại các ô từng bị khuất góc
                failedTargetCooldowns.clear();
                attemptedSidesPerPos.clear();
            }
            lastPlayerBlockPos = currentPos;
        }

        decrementMap(recentAttemptCooldowns);
        decrementMap(failedTargetCooldowns);
    }

    private void decrementMap(Map<BlockPos, Integer> map) {
        if (!map.isEmpty()) {
            Iterator<Map.Entry<BlockPos, Integer>> it = map.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<BlockPos, Integer> entry = it.next();
                int left = entry.getValue() - 1;
                if (left <= 0) {
                    it.remove();
                } else {
                    entry.setValue(left);
                }
            }
        }
    }

    public boolean hasPendingTask() {
        return pendingTask != null || readyForEndTickTask != null;
    }

    public boolean hasReadyEndTickTask() {
        return readyForEndTickTask != null;
    }

    public BlockPos getCurrentHighlightedTarget() {
        if (readyForEndTickTask != null) {
            return readyForEndTickTask.targetPos();
        }
        if (pendingTask != null) {
            return pendingTask.targetPos();
        }
        return currentHighlightedTarget;
    }

    public BlockPos getBlockedByHitboxPos() {
        return blockedByHitboxPos;
    }

    public String getCurrentActionStatus() {
        return currentActionStatus;
    }

    /**
     * Được gọi trong START_CLIENT_TICK khi đang có mục tiêu đang xoay dở từ tick trước.
     */
    public void tickStartPendingRotation(
            MinecraftClient client,
            PrinterConfig config,
            InventoryManager inventoryManager
    ) {
        if (pendingTask == null) {
            return;
        }
        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        if (player == null || world == null) {
            pendingTask = null;
            return;
        }

        PlacementTask task = pendingTask;
        if (!canStillPlaceAtTarget(world, player, task, config)) {
            pendingTask = null;
            pendingWaitTicks = 0;
            return;
        }

        if (!inventoryManager.equipItemForPlacement(client, task.requiredItem(), config)) {
            pendingTask = null;
            pendingWaitTicks = 0;
            return;
        }

        pendingWaitTicks++;
        int maxAllowedRotateTicks = Math.max(2, Math.min(10, Math.round(170.0f / Math.max(12.0f, config.maxRotationStep)) + 1));

        boolean converged = applySmoothRotation(
                player,
                task.requiredYaw(),
                task.requiredPitch(),
                config.maxRotationStep,
                config.smoothHumanRotationCurve
        );

        if (converged || pendingWaitTicks >= maxAllowedRotateTicks) {
            // Khóa chính xác góc đích để ClientPlayerEntity.sendMovementPackets() gửi gói tin chuẩn lên Server ở giữa tick!
            player.setYaw(task.requiredYaw());
            player.setPitch(task.requiredPitch());
            readyForEndTickTask = task;
            pendingTask = null;
            pendingWaitTicks = 0;
        }
    }

    /**
     * Được gọi trong START_CLIENT_TICK để tìm khối tiếp theo và bắt đầu xoay góc nhìn.
     */
    public boolean findAndScheduleNext(
            MinecraftClient client,
            World schematicWorld,
            PrinterConfig config,
            InventoryManager inventoryManager,
            SchematicAnalyzer analyzer,
            ScaffoldPlanner scaffoldPlanner
    ) {
        tickCooldownMap(client.player);

        PlacementTask next = findNextPlaceableBlock(
                client,
                schematicWorld,
                config,
                inventoryManager,
                analyzer,
                scaffoldPlanner
        );
        if (next == null) {
            currentHighlightedTarget = null;
            return false;
        }

        if (!inventoryManager.equipItemForPlacement(client, next.requiredItem(), config)) {
            currentActionStatus = "Chờ nạp: " + next.requiredItem().getName().getString();
            return false;
        }

        currentHighlightedTarget = next.targetPos();
        blockedByHitboxPos = null;

        if (config.antiCheatStrictMode) {
            boolean convergedImmediately = applySmoothRotation(
                    client.player,
                    next.requiredYaw(),
                    next.requiredPitch(),
                    config.maxRotationStep,
                    config.smoothHumanRotationCurve
            );
            if (convergedImmediately) {
                // Nếu góc xoay đã tới đích ngay trong START_CLIENT_TICK, khóa góc chuẩn để giữa tick gửi lên Server
                // và đặt ngay ở END_CLIENT_TICK của cùng tick này!
                client.player.setYaw(next.requiredYaw());
                client.player.setPitch(next.requiredPitch());
                readyForEndTickTask = next;
                pendingTask = null;
                pendingWaitTicks = 0;
            } else {
                pendingTask = next;
                readyForEndTickTask = null;
                pendingWaitTicks = 0;
            }
            currentActionStatus = (next.isTemporaryScaffold() ? "Đang kê block tại Y=" : "Đang đặt khối tại Y=")
                    + next.targetPos().getY();
        } else {
            client.player.setYaw(next.requiredYaw());
            client.player.setPitch(next.requiredPitch());
            readyForEndTickTask = next;
            pendingTask = null;
            pendingWaitTicks = 0;
            currentActionStatus = "Đặt nhanh tại Y=" + next.targetPos().getY();
        }
        return true;
    }

    /**
     * Được gọi trong END_CLIENT_TICK (SAU KHI ClientPlayerEntity.sendMovementPackets() đã gửi góc nhìn mới lên Server!).
     * Đảm bảo 100% Server nhận được đúng Yaw/Pitch trước khi xử lý gói tin interactBlock!
     */
    public boolean executeEndTickPlacement(
            MinecraftClient client,
            PrinterConfig config,
            InventoryManager inventoryManager,
            ScaffoldPlanner scaffoldPlanner
    ) {
        if (readyForEndTickTask == null) {
            return false;
        }
        PlacementTask task = readyForEndTickTask;
        readyForEndTickTask = null;

        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        ClientPlayerInteractionManager interactionManager = client.interactionManager;
        if (player == null || world == null || interactionManager == null) {
            return false;
        }

        if (!canStillPlaceAtTarget(world, player, task, config)) {
            return false;
        }

        if (!inventoryManager.equipItemForPlacement(client, task.requiredItem(), config)) {
            return false;
        }

        // Giữ nguyên góc đích đã đồng bộ lên Server
        player.setYaw(task.requiredYaw());
        player.setPitch(task.requiredPitch());

        Vec3d finalHitVec = config.antiCheatStrictMode
                ? task.hitVec()
                : applyEasyPlaceProtocolOffset(task.hitVec(), task.targetPos(), task.schematicState());

        BlockHitResult hitResult = new BlockHitResult(
                finalHitVec,
                task.clickSide(),
                task.neighborPos(),
                false
        );

        // Ghi nhận lịch sử thử đặt tại tọa độ này để chống lặp xoay đầu nếu Server rollback về AIR
        BlockPos immPos = task.targetPos().toImmutable();
        recentAttemptCooldowns.put(immPos, 10);
        attemptedSidesPerPos.computeIfAbsent(immPos, k -> EnumSet.noneOf(Direction.class)).add(task.clickSide());
        int attempts = targetFailCounts.getOrDefault(immPos, 0) + 1;
        if (attempts >= 3) {
            failedTargetCooldowns.put(immPos, 80);
            targetFailCounts.remove(immPos);
        } else {
            targetFailCounts.put(immPos, attempts);
        }

        Hand handToUse = player.getOffHandStack().isOf(task.requiredItem()) ? Hand.OFF_HAND : Hand.MAIN_HAND;
        ActionResult result = interactionManager.interactBlock(player, handToUse, hitResult);
        if (result.isAccepted()) {
            player.swingHand(handToUse);
            if (task.isTemporaryScaffold()) {
                scaffoldPlanner.markTemporaryScaffold(task.targetPos());
            }
            return true;
        }
        return false;
    }

    private boolean canStillPlaceAtTarget(
            ClientWorld world,
            ClientPlayerEntity player,
            PlacementTask task,
            PrinterConfig config
    ) {
        BlockState worldState = world.getBlockState(task.targetPos());
        if (!isTargetNeedingPlacement(worldState, task.schematicState())) {
            return false;
        }
        double maxReachSq = (config.maxReachDistance + 0.35) * (config.maxReachDistance + 0.35);
        if (player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(task.targetPos())) > maxReachSq) {
            return false;
        }
        if (task.targetPos().equals(player.getBlockPos())
                || task.targetPos().equals(player.getBlockPos().up())
                || SmartPathfinder.isPlayerIntersectingBlock(player, task.targetPos())) {
            this.blockedByHitboxPos = task.targetPos();
            return false;
        }
        return true;
    }

    /**
     * Kiểm tra xem ô targetPos có đang cần đặt khối (hoặc cần ghép thêm nửa thứ 2 của Double Slab) không.
     */
    public static boolean isTargetNeedingPlacement(BlockState worldState, BlockState schematicState) {
        if (worldState.isReplaceable()) {
            return true;
        }
        // Hỗ trợ ghép nửa thứ 2 cho SlabType.DOUBLE
        if (schematicState.getBlock() instanceof SlabBlock
                && schematicState.contains(Properties.SLAB_TYPE)
                && schematicState.get(Properties.SLAB_TYPE) == SlabType.DOUBLE) {
            if (worldState.getBlock() == schematicState.getBlock()
                    && worldState.contains(Properties.SLAB_TYPE)
                    && worldState.get(Properties.SLAB_TYPE) != SlabType.DOUBLE) {
                return true;
            }
        }
        return false;
    }

    private PlacementTask findNextPlaceableBlock(
            MinecraftClient client,
            World schematicWorld,
            PrinterConfig config,
            InventoryManager inventoryManager,
            SchematicAnalyzer analyzer,
            ScaffoldPlanner scaffoldPlanner
    ) {
        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        BlockPos playerPos = player.getBlockPos();
        Vec3d eyePos = player.getEyePos();

        this.blockedByHitboxPos = null;

        Integer globalLockedY = config.strictLayerByLayer ? analyzer.getActiveLayerY() : null;
        if (config.strictLayerByLayer && globalLockedY != null) {
            if (!analyzer.hasRemainingUnbuiltOnLayer(world, schematicWorld, playerPos, globalLockedY, config.layerScanRadius, config)) {
                analyzer.updateAnalysis(client, schematicWorld, config, inventoryManager, true);
                globalLockedY = analyzer.getActiveLayerY();
            }
        }

        if (config.strictLayerByLayer && globalLockedY == null) {
            this.currentActionStatus = "Đã xây xong toàn bộ các tầng trong vùng quét!";
            return null;
        }

        int radius = (int) Math.ceil(config.maxReachDistance);
        double maxReachSq = config.maxReachDistance * config.maxReachDistance;

        List<BlockPos> candidates = new ArrayList<>();
        BlockPos nearestHitboxBlocked = null;
        double nearestBlockedDistSq = Double.MAX_VALUE;

        for (int dy = -radius; dy <= radius; dy++) {
            int y = playerPos.getY() + dy;

            if (config.strictLayerByLayer && globalLockedY != null && y != globalLockedY) {
                continue;
            }

            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    BlockPos pos = new BlockPos(playerPos.getX() + dx, y, playerPos.getZ() + dz);
                    if (recentAttemptCooldowns.containsKey(pos) || failedTargetCooldowns.containsKey(pos)) {
                        continue;
                    }

                    double distSq = eyePos.squaredDistanceTo(Vec3d.ofCenter(pos));
                    if (distSq > maxReachSq || !LitematicaBridge.isWithinLayerRange(pos)) {
                        continue;
                    }

                    BlockState schematicState = schematicWorld.getBlockState(pos);
                    if (schematicState.isAir() || !schematicState.getFluidState().isEmpty()) {
                        continue;
                    }

                    if (!config.isBlockAllowed(schematicState.getBlock())) {
                        continue;
                    }

                    BlockState clientState = world.getBlockState(pos);
                    if (SchematicAnalyzer.isStateMatching(clientState, schematicState)) {
                        // Đã đặt đúng trên thế giới -> Xóa lịch sử lỗi nếu có
                        targetFailCounts.remove(pos);
                        attemptedSidesPerPos.remove(pos);
                        continue;
                    }

                    if (!isTargetNeedingPlacement(clientState, schematicState)) {
                        continue;
                    }

                    Item requiredItem = schematicState.getBlock().asItem();
                    if (requiredItem == Items.AIR || !inventoryManager.hasItemReadyForImmediateUse(player, requiredItem, config)) {
                        continue;
                    }

                    if (pos.equals(playerPos) || pos.equals(playerPos.up())
                            || SmartPathfinder.isPlayerIntersectingBlock(player, pos)
                            || (clientState.isReplaceable() && !world.canPlace(schematicState, pos, ShapeContext.of(player)))) {
                        if (distSq < nearestBlockedDistSq) {
                            nearestBlockedDistSq = distSq;
                            nearestHitboxBlocked = pos;
                        }
                        continue;
                    }

                    candidates.add(pos);
                }
            }
        }

        // SẮP XẾP QUÉT MƯỢT THEO GÓC NHÌN HIỆN TẠI (Angular Sweep Sorting):
        // Giúp đầu nhân vật lia mượt theo 1 vòng tròn liền mạch thay vì giật 180° trước-sau!
        final float currentYaw = player.getYaw();
        candidates.sort(Comparator
                .<BlockPos>comparingInt(BlockPos::getY)
                .thenComparingDouble((BlockPos p) -> {
                    Vec3d center = Vec3d.ofCenter(p);
                    float yawToBlock = (float) (MathHelper.atan2(center.z - eyePos.z, center.x - eyePos.x) * (180.0 / Math.PI)) - 90.0f;
                    float angleDiff = Math.abs(MathHelper.wrapDegrees(yawToBlock - currentYaw));
                    double dist = Math.sqrt(eyePos.squaredDistanceTo(center));
                    return angleDiff * 0.35 - dist * 4.0;
                }));

        List<BlockPos> floatingCandidates = new ArrayList<>();
        for (BlockPos pos : candidates) {
            BlockState schematicState = schematicWorld.getBlockState(pos);
            Item requiredItem = schematicState.getBlock().asItem();

            PlacementTask task = computeSupportPlacement(client, pos, schematicState, requiredItem, config, false);
            if (task != null) {
                return task;
            } else {
                floatingCandidates.add(pos);
            }
        }

        if (config.autoScaffoldEnabled && !floatingCandidates.isEmpty()) {
            for (BlockPos floatingPos : floatingCandidates) {
                ScaffoldPlanner.ScaffoldCandidate bridge = scaffoldPlanner.findBridgeScaffoldForFloatingTarget(
                        client,
                        schematicWorld,
                        floatingPos,
                        config,
                        inventoryManager
                );
                if (bridge != null
                        && !recentAttemptCooldowns.containsKey(bridge.scaffoldPos())
                        && !failedTargetCooldowns.containsKey(bridge.scaffoldPos())) {
                    PlacementTask scaffoldTask = computeSupportPlacement(
                            client,
                            bridge.scaffoldPos(),
                            bridge.desiredState(),
                            bridge.itemToUse(),
                            config,
                            bridge.isTemporaryScaffold()
                    );
                    if (scaffoldTask != null) {
                        currentActionStatus = "Đang đặt Block Kê cho tầng Y=" + floatingPos.getY();
                        return scaffoldTask;
                    }
                }
            }
        }

        if (nearestHitboxBlocked != null) {
            this.blockedByHitboxPos = nearestHitboxBlocked;
            this.currentHighlightedTarget = nearestHitboxBlocked;
            this.currentActionStatus = "Vướng Hitbox tại Y=" + nearestHitboxBlocked.getY() + " — đang lùi ra!";
            return null;
        }

        if (!analyzer.getLastMissingItemHint().isEmpty()) {
            this.currentActionStatus = "Tầng Y=" + (globalLockedY != null ? globalLockedY : "?")
                    + " thiếu: " + analyzer.getLastMissingItemHint();
        } else if (globalLockedY != null) {
            this.currentActionStatus = "Di chuyển tới xây nốt tầng Y=" + globalLockedY
                    + " (Còn " + analyzer.getActiveLayerRemainingCount() + " khối)";
        } else {
            this.currentActionStatus = "Di chuyển tới khối tiếp theo...";
        }

        return null;
    }

    private PlacementTask computeSupportPlacement(
            MinecraftClient client,
            BlockPos targetPos,
            BlockState schematicState,
            Item requiredItem,
            PrinterConfig config,
            boolean isTemporaryScaffold
    ) {
        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        Vec3d eyePos = player.getEyePos();
        double maxReachSq = (config.maxReachDistance + 0.25) * (config.maxReachDistance + 0.25);

        // Trường hợp đặc biệt: Ghép nửa thứ 2 của Double Slab lên nửa thứ nhất đã có sẵn tại targetPos
        BlockState currentWorldState = world.getBlockState(targetPos);
        if (schematicState.getBlock() instanceof SlabBlock
                && schematicState.contains(Properties.SLAB_TYPE)
                && schematicState.get(Properties.SLAB_TYPE) == SlabType.DOUBLE
                && currentWorldState.getBlock() == schematicState.getBlock()
                && currentWorldState.contains(Properties.SLAB_TYPE)
                && currentWorldState.get(Properties.SLAB_TYPE) != SlabType.DOUBLE) {
            SlabType existingHalf = currentWorldState.get(Properties.SLAB_TYPE);
            Direction clickSide = (existingHalf == SlabType.BOTTOM) ? Direction.UP : Direction.DOWN;
            Vec3d hitVec = Vec3d.ofCenter(targetPos);
            if (eyePos.squaredDistanceTo(hitVec) <= maxReachSq) {
                float[] rotations = computeAnglesForState(eyePos, hitVec, schematicState);
                return new PlacementTask(
                        targetPos,
                        targetPos,
                        clickSide,
                        hitVec,
                        rotations[0],
                        rotations[1],
                        requiredItem,
                        schematicState,
                        false
                );
            }
            return null;
        }

        List<Direction> preferredDirs = getPreferredSupportDirections(schematicState);
        Set<Direction> alreadyTriedSides = attemptedSidesPerPos.get(targetPos);

        PlacementTask bestTask = null;
        double bestFaceScore = Double.MAX_VALUE;

        for (Direction dir : preferredDirs) {
            BlockPos neighborPos = targetPos.offset(dir);
            BlockState neighborState = world.getBlockState(neighborPos);

            if (neighborState.isAir() || neighborState.isReplaceable()) {
                continue;
            }

            Direction clickSide = dir.getOpposite();
            if (!isClickSideCompatibleWithState(clickSide, schematicState)) {
                continue;
            }

            Vec3d hitVec = computeHitVecForBlockState(neighborPos, clickSide, schematicState);
            double distSq = eyePos.squaredDistanceTo(hitVec);
            if (distSq > maxReachSq) {
                continue;
            }

            if (config.antiCheatStrictMode && !hasLineOfSight(world, player, eyePos, targetPos, neighborPos, hitVec)) {
                continue;
            }

            float[] rotations = computeAnglesForState(eyePos, hitVec, schematicState);

            // Chấm điểm mặt click: Ưu tiên mặt chưa từng bị server từ chối, mặt hướng trực diện về phía mắt người chơi,
            // và mặt sàn/trần chuẩn cho Slab/Stairs
            double score = distSq;
            if (alreadyTriedSides != null && alreadyTriedSides.contains(clickSide)) {
                score += 50.0;
            }
            Vec3d toEye = eyePos.subtract(hitVec).normalize();
            double facingDot = toEye.x * clickSide.getOffsetX() + toEye.y * clickSide.getOffsetY() + toEye.z * clickSide.getOffsetZ();
            score -= facingDot * 8.0; // Ưu tiên mặt quay về phía mắt người chơi (facingDot > 0)
            if (preferredDirs.indexOf(dir) == 0) {
                score -= 12.0; // Ưu tiên mặt chính (ví dụ mặt UP/DOWN cho Slab/Stairs hoặc ống Hopper)
            }

            if (score < bestFaceScore) {
                bestFaceScore = score;
                bestTask = new PlacementTask(
                        targetPos,
                        neighborPos,
                        clickSide,
                        hitVec,
                        rotations[0],
                        rotations[1],
                        requiredItem,
                        schematicState,
                        isTemporaryScaffold
                );
            }
        }

        return bestTask;
    }

    private List<Direction> getPreferredSupportDirections(BlockState state) {
        List<Direction> dirs = new ArrayList<>();
        Block block = state.getBlock();

        // 1. Hopper (Phễu): Ưu tiên bấm vào khối ở phía ống phễu chĩa vào (neighbor = targetPos.offset(hopperFacing))
        if (block instanceof HopperBlock && state.contains(Properties.HOPPER_FACING)) {
            dirs.add(state.get(Properties.HOPPER_FACING));
        }

        // 2. Các khối gắn tường/sàn/trần (Button, Lever, Grindstone)
        if (block instanceof WallMountedBlock && state.contains(Properties.BLOCK_FACE)) {
            BlockFace face = state.get(Properties.BLOCK_FACE);
            if (face == BlockFace.FLOOR) {
                dirs.add(Direction.DOWN);
            } else if (face == BlockFace.CEILING) {
                dirs.add(Direction.UP);
            } else if (state.contains(Properties.HORIZONTAL_FACING)) {
                dirs.add(state.get(Properties.HORIZONTAL_FACING).getOpposite());
            }
        }

        // 3. Slab / Stairs / Trapdoor: Ưu tiên mặt sàn dưới (BOTTOM) hoặc trần trên (TOP)
        if (block instanceof SlabBlock && state.contains(Properties.SLAB_TYPE)) {
            SlabType type = state.get(Properties.SLAB_TYPE);
            if (type == SlabType.BOTTOM || type == SlabType.DOUBLE) {
                dirs.add(Direction.DOWN);
            } else if (type == SlabType.TOP) {
                dirs.add(Direction.UP);
            }
        } else if ((block instanceof StairsBlock || block instanceof TrapdoorBlock)
                && state.contains(Properties.BLOCK_HALF)) {
            BlockHalf half = state.get(Properties.BLOCK_HALF);
            if (half == BlockHalf.BOTTOM) {
                dirs.add(Direction.DOWN);
            } else {
                dirs.add(Direction.UP);
            }
        }

        for (Direction d : Direction.values()) {
            if (!dirs.contains(d)) {
                dirs.add(d);
            }
        }
        return dirs;
    }

    private boolean isClickSideCompatibleWithState(Direction clickSide, BlockState schematicState) {
        Block block = schematicState.getBlock();

        // 1. HopperBlock: Miệng ống phễu luôn nối vào mặt clickSide.getOpposite()
        if (block instanceof HopperBlock && schematicState.contains(Properties.HOPPER_FACING)) {
            Direction desiredHopperFacing = schematicState.get(Properties.HOPPER_FACING);
            Direction placedFacing = (clickSide.getAxis() == Direction.Axis.Y) ? Direction.DOWN : clickSide.getOpposite();
            return placedFacing == desiredHopperFacing;
        }

        // 2. WallMountedBlock (Button, Lever, Grindstone)
        if (block instanceof WallMountedBlock && schematicState.contains(Properties.BLOCK_FACE)) {
            BlockFace face = schematicState.get(Properties.BLOCK_FACE);
            if (face == BlockFace.FLOOR) {
                return clickSide == Direction.UP;
            }
            if (face == BlockFace.CEILING) {
                return clickSide == Direction.DOWN;
            }
            if (face == BlockFace.WALL && schematicState.contains(Properties.HORIZONTAL_FACING)) {
                return clickSide == schematicState.get(Properties.HORIZONTAL_FACING);
            }
        }

        // 3. Khối gắn tường ngang (Ladder, WallTorch, WallSign, WallBanner, TripwireHook, Cocoa)
        if ((block instanceof LadderBlock || block instanceof WallTorchBlock
                || block instanceof WallBannerBlock || block instanceof TripwireHookBlock
                || (block instanceof AbstractSignBlock && schematicState.contains(Properties.HORIZONTAL_FACING)))
                && schematicState.contains(Properties.HORIZONTAL_FACING)) {
            return clickSide == schematicState.get(Properties.HORIZONTAL_FACING);
        }
        if (block instanceof CocoaBlock && schematicState.contains(Properties.HORIZONTAL_FACING)) {
            return clickSide == schematicState.get(Properties.HORIZONTAL_FACING).getOpposite();
        }

        // 4. EndRod, LightningRod, AmethystCluster, ShulkerBox: Hướng FACING lấy trực tiếp từ clickSide
        if ((block instanceof EndRodBlock || block instanceof LightningRodBlock
                || block instanceof AmethystClusterBlock || block instanceof ShulkerBoxBlock)
                && schematicState.contains(Properties.FACING)) {
            return clickSide == schematicState.get(Properties.FACING);
        }

        // 5. SlabBlock: Không bấm mặt dưới nếu là BOTTOM slab, không bấm mặt trên nếu là TOP slab
        if (block instanceof SlabBlock && schematicState.contains(Properties.SLAB_TYPE)) {
            SlabType type = schematicState.get(Properties.SLAB_TYPE);
            if (type == SlabType.BOTTOM && clickSide == Direction.DOWN) {
                return false;
            }
            if (type == SlabType.TOP && clickSide == Direction.UP) {
                return false;
            }
        }

        // 6. StairsBlock & TrapdoorBlock (nửa trên / nửa dưới)
        if ((block instanceof StairsBlock || block instanceof TrapdoorBlock)
                && schematicState.contains(Properties.BLOCK_HALF)) {
            BlockHalf half = schematicState.get(Properties.BLOCK_HALF);
            if (half == BlockHalf.BOTTOM && clickSide == Direction.DOWN) {
                return false;
            }
            if (half == BlockHalf.TOP && clickSide == Direction.UP) {
                return false;
            }
        }

        // Với TrapdoorBlock: Nếu bấm vào mặt ngang của khối bên cạnh, Vanilla ép hướng Trapdoor theo clickSide
        if (block instanceof TrapdoorBlock && schematicState.contains(Properties.HORIZONTAL_FACING)) {
            if (clickSide.getAxis().isHorizontal()) {
                Direction desiredFacing = schematicState.get(Properties.HORIZONTAL_FACING);
                if (clickSide != desiredFacing) {
                    return false;
                }
            }
        }

        // 7. PillarBlock (Gỗ khúc Log, Quartz Pillar, Basalt, Hay Bale...): Trục AXIS phụ thuộc 100% vào clickSide.getAxis()
        if (block instanceof PillarBlock && schematicState.contains(Properties.AXIS)) {
            Direction.Axis desiredAxis = schematicState.get(Properties.AXIS);
            if (clickSide.getAxis() != desiredAxis) {
                return false;
            }
        }

        return true;
    }

    private Vec3d computeHitVecForBlockState(BlockPos neighborPos, Direction clickSide, BlockState schematicState) {
        double x = neighborPos.getX() + 0.5 + clickSide.getOffsetX() * 0.5;
        double y = neighborPos.getY() + 0.5 + clickSide.getOffsetY() * 0.5;
        double z = neighborPos.getZ() + 0.5 + clickSide.getOffsetZ() * 0.5;

        Block block = schematicState.getBlock();
        if (clickSide.getAxis().isHorizontal()) {
            if (block instanceof SlabBlock && schematicState.contains(Properties.SLAB_TYPE)) {
                SlabType type = schematicState.get(Properties.SLAB_TYPE);
                y = neighborPos.getY() + (type == SlabType.TOP ? 0.85 : 0.15);
            } else if ((block instanceof StairsBlock || block instanceof TrapdoorBlock)
                    && schematicState.contains(Properties.BLOCK_HALF)) {
                BlockHalf half = schematicState.get(Properties.BLOCK_HALF);
                y = neighborPos.getY() + (half == BlockHalf.TOP ? 0.85 : 0.15);
            }
        }
        return new Vec3d(x, y, z);
    }

    /**
     * Tính góc nhìn (Yaw, Pitch) chuẩn xác 100% theo quy tắc Vanilla Minecraft 1.21.11:
     * - Với các khối chỉ phụ thuộc vào mặt click (Stone, Dirt, Log, Slab, Hopper, Ladder, EndRod...):
     *   Giữ nguyên góc ngắm thẳng vào hitVec!
     * - Với các khối phụ thuộc góc nhìn người chơi (Stairs, Repeater, Comparator, Observer, Piston, Furnace, Chest, Anvil...):
     *   Kẹp góc Yaw vào vùng an toàn [-25°, +25°] quanh tâm hướng chuẩn để Direction.fromHorizontalDegrees(yaw)
     *   luôn trả về đúng 100% hướng của bản vẽ!
     */
    public static float[] computeAnglesForState(Vec3d eyePos, Vec3d hitVec, BlockState state) {
        double dx = hitVec.x - eyePos.x;
        double dy = hitVec.y - eyePos.y;
        double dz = hitVec.z - eyePos.z;
        double horizDist = Math.sqrt(dx * dx + dz * dz);

        float aimYaw = (float) (MathHelper.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        float aimPitch = (float) (-(MathHelper.atan2(dy, horizDist) * (180.0 / Math.PI)));

        Block block = state.getBlock();

        // Các khối đặt theo mặt clickSide, KHÔNG phụ thuộc vào góc nhìn của người chơi:
        if (block instanceof HopperBlock
                || block instanceof LadderBlock
                || block instanceof WallTorchBlock
                || block instanceof WallBannerBlock
                || block instanceof TripwireHookBlock
                || block instanceof EndRodBlock
                || block instanceof LightningRodBlock
                || block instanceof AmethystClusterBlock
                || block instanceof ShulkerBoxBlock) {
            return new float[]{MathHelper.wrapDegrees(aimYaw), MathHelper.clamp(aimPitch, -90.0f, 90.0f)};
        }

        if (state.contains(Properties.HORIZONTAL_FACING)) {
            Direction facing = state.get(Properties.HORIZONTAL_FACING);
            Direction requiredPlayerFacing;

            if (block instanceof StairsBlock || block instanceof FenceGateBlock) {
                // Cầu thang & Cổng rào: Hướng của khối CÙNG CHIỀU với hướng nhìn của người chơi
                requiredPlayerFacing = facing;
            } else if (block instanceof AnvilBlock || block instanceof BellBlock) {
                // Đe (Anvil): Vanilla dùng ctx.getHorizontalPlayerFacing().rotateYClockwise()
                requiredPlayerFacing = facing.rotateYCounterclockwise();
            } else if (block instanceof WallMountedBlock && state.contains(Properties.BLOCK_FACE)) {
                BlockFace face = state.get(Properties.BLOCK_FACE);
                if (face == BlockFace.WALL) {
                    return new float[]{MathHelper.wrapDegrees(aimYaw), MathHelper.clamp(aimPitch, -90.0f, 90.0f)};
                }
                requiredPlayerFacing = facing;
            } else {
                // Repeater, Comparator, Furnace, Chest, EnderChest, Lectern, Trapdoor, Stonecutter, Loom...:
                // Trong Vanilla 1.21.11, chúng lấy ctx.getHorizontalPlayerFacing().getOpposite()!
                requiredPlayerFacing = facing.getOpposite();
            }

            float cardinalYaw = requiredPlayerFacing.getPositiveHorizontalDegrees();
            float diff = MathHelper.wrapDegrees(aimYaw - cardinalYaw);
            // Kẹp trong khoảng [-25°, +25°] quanh tâm hướng chuẩn để đảm bảo 100% nằm trọn trong góc phần tư [-45°, +45°]
            float clampedYaw = cardinalYaw + MathHelper.clamp(diff, -25.0f, 25.0f);
            return new float[]{MathHelper.wrapDegrees(clampedYaw), MathHelper.clamp(aimPitch, -90.0f, 90.0f)};
        }

        if (state.contains(Properties.FACING)) {
            Direction facing = state.get(Properties.FACING);
            boolean facesSameAsPlayerLook = (block instanceof ObserverBlock);
            Direction requiredLookDir = facesSameAsPlayerLook ? facing : facing.getOpposite();

            if (requiredLookDir == Direction.UP) {
                // Nhìn LÊN trời trong Minecraft là Pitch ÂM (-88°)
                return new float[]{MathHelper.wrapDegrees(aimYaw), -88.0f};
            } else if (requiredLookDir == Direction.DOWN) {
                // Nhìn XUỐNG đất trong Minecraft là Pitch DƯƠNG (+88°)
                return new float[]{MathHelper.wrapDegrees(aimYaw), 88.0f};
            } else {
                float cardinalYaw = requiredLookDir.getPositiveHorizontalDegrees();
                float diff = MathHelper.wrapDegrees(aimYaw - cardinalYaw);
                float clampedYaw = cardinalYaw + MathHelper.clamp(diff, -25.0f, 25.0f);
                // Giữ pitch trong [-25°, +25°] để Direction.getEntityFacingOrder() luôn chọn hướng NGANG thay vì UP/DOWN!
                float clampedPitch = MathHelper.clamp(aimPitch, -25.0f, 25.0f);
                return new float[]{MathHelper.wrapDegrees(clampedYaw), clampedPitch};
            }
        }

        return new float[]{MathHelper.wrapDegrees(aimYaw), MathHelper.clamp(aimPitch, -90.0f, 90.0f)};
    }

    private Vec3d applyEasyPlaceProtocolOffset(Vec3d baseHitVec, BlockPos targetPos, BlockState schematicState) {
        double protocolX = targetPos.getX();
        if (schematicState.contains(Properties.HORIZONTAL_FACING)) {
            Direction facing = schematicState.get(Properties.HORIZONTAL_FACING);
            protocolX = protocolX + (facing.getIndex() * 2) + 2;
        } else if (schematicState.contains(Properties.FACING)) {
            Direction facing = schematicState.get(Properties.FACING);
            protocolX = protocolX + (facing.getIndex() * 2) + 2;
        } else if (schematicState.contains(Properties.HOPPER_FACING)) {
            Direction facing = schematicState.get(Properties.HOPPER_FACING);
            protocolX = protocolX + (facing.getIndex() * 2) + 2;
        }
        if (schematicState.contains(Properties.BLOCK_HALF)
                && schematicState.get(Properties.BLOCK_HALF) == BlockHalf.TOP) {
            protocolX += 16;
        } else if (schematicState.contains(Properties.SLAB_TYPE)
                && schematicState.get(Properties.SLAB_TYPE) == SlabType.TOP) {
            protocolX += 16;
        }
        return new Vec3d(protocolX, baseHitVec.y, baseHitVec.z);
    }

    private boolean hasLineOfSight(
            ClientWorld world,
            ClientPlayerEntity player,
            Vec3d eyePos,
            BlockPos targetPos,
            BlockPos neighborPos,
            Vec3d hitVec
    ) {
        BlockHitResult raycast = world.raycast(new RaycastContext(
                eyePos,
                hitVec,
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                player
        ));
        if (raycast.getType() == HitResult.Type.MISS) {
            return true;
        }
        BlockPos hitBlock = raycast.getBlockPos();
        if (hitBlock.equals(neighborPos) || hitBlock.equals(targetPos)) {
            return true;
        }
        return raycast.getPos().squaredDistanceTo(hitVec) <= 0.55;
    }

    public static boolean applySmoothRotation(
            ClientPlayerEntity player,
            float targetYaw,
            float targetPitch,
            float maxStep,
            boolean smoothCurve
    ) {
        float currentYaw = player.getYaw();
        float currentPitch = player.getPitch();

        float deltaYaw = MathHelper.wrapDegrees(targetYaw - currentYaw);
        float deltaPitch = targetPitch - currentPitch;

        if (Math.abs(deltaYaw) <= 2.2f && Math.abs(deltaPitch) <= 2.2f) {
            player.setYaw(targetYaw);
            player.setPitch(MathHelper.clamp(targetPitch, -90.0f, 90.0f));
            return true;
        }

        float effectiveStepYaw = maxStep;
        float effectiveStepPitch = maxStep;

        if (smoothCurve && maxStep < 150.0f) {
            effectiveStepYaw = Math.min(maxStep, Math.max(4.5f, Math.abs(deltaYaw) * 0.68f));
            effectiveStepPitch = Math.min(maxStep, Math.max(4.0f, Math.abs(deltaPitch) * 0.68f));
        }

        float stepYaw = MathHelper.clamp(deltaYaw, -effectiveStepYaw, effectiveStepYaw);
        float stepPitch = MathHelper.clamp(deltaPitch, -effectiveStepPitch, effectiveStepPitch);

        float gcd = 0.15f;
        stepYaw = Math.round(stepYaw / gcd) * gcd;
        stepPitch = Math.round(stepPitch / gcd) * gcd;

        float newYaw = currentYaw + stepYaw;
        float newPitch = MathHelper.clamp(currentPitch + stepPitch, -90.0f, 90.0f);

        player.setYaw(newYaw);
        player.setPitch(newPitch);

        float remainingYaw = Math.abs(MathHelper.wrapDegrees(targetYaw - newYaw));
        float remainingPitch = Math.abs(targetPitch - newPitch);
        return remainingYaw <= 2.5f && remainingPitch <= 2.5f;
    }

    public static boolean applySmoothRotation(
            ClientPlayerEntity player,
            float targetYaw,
            float targetPitch,
            float maxStep
    ) {
        return applySmoothRotation(player, targetYaw, targetPitch, maxStep, true);
    }
}
