package net.autobuild.litematica;

import javazoom.jl.player.Player;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineEvent;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

/**
 * Bộ quản lý nhạc nền (Hỗ trợ phát trực tiếp .mp3 & .wav trong game + Chống Spam 100%).
 */
public class MusicManager {

    private static final Path MUSIC_DIR = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("litematica_autobuild")
            .resolve("music");

    private final AtomicInteger playbackGeneration = new AtomicInteger(0);
    private final Object audioLock = new Object();

    private boolean musicSessionActive = false;
    private int currentLocalTrackIndex = 0;
    private volatile String currentTrackLabel = "Chưa phát";

    private volatile Player activeMp3Player = null;
    private volatile Clip activeWavClip = null;
    private volatile Thread activeWorkerThread = null;
    private long lastBrowserOpenEpochMs = 0L;

    public MusicManager() {
        ensureMusicDirectoryExists();
    }

    public static Path getMusicDirectory() {
        ensureMusicDirectoryExists();
        return MUSIC_DIR;
    }

    private static void ensureMusicDirectoryExists() {
        try {
            Files.createDirectories(MUSIC_DIR);
        } catch (IOException ignored) {
        }
    }

    public void tick(MinecraftClient client, PrinterConfig config) {
        boolean shouldPlay = config.printerEnabled && config.musicEnabled;

        if (!shouldPlay) {
            if (musicSessionActive) {
                musicSessionActive = false;
                stopActiveAudio();
            }
            return;
        }

        if (!musicSessionActive) {
            musicSessionActive = true;
            startMusicSession(client, config);
        }
    }

    public void onMusicSettingChanged(MinecraftClient client, PrinterConfig config, boolean forceRestart) {
        if (forceRestart) {
            musicSessionActive = false;
            stopActiveAudio();
        }
        tick(client, config);
    }

    public void skipToNextLocalTrack(MinecraftClient client, PrinterConfig config) {
        if (config.useLocalMusicFolder) {
            currentLocalTrackIndex++;
            startLocalPlaylistLoop(client, config);
        } else {
            openYoutubeLinkInBrowser(client, config.youtubeLink);
        }
    }

    private void startMusicSession(MinecraftClient client, PrinterConfig config) {
        stopActiveAudio();
        if (config.useLocalMusicFolder) {
            List<Path> tracks = listLocalMusicFiles();
            if (tracks.isEmpty()) {
                notifyPlayer(client, "§eFolder music chưa có file .mp3/.wav — mở link YouTube!");
                openYoutubeLinkInBrowser(client, config.youtubeLink);
            } else {
                startLocalPlaylistLoop(client, config);
            }
        } else {
            openYoutubeLinkInBrowser(client, config.youtubeLink);
        }
    }

    private void startLocalPlaylistLoop(MinecraftClient client, PrinterConfig config) {
        stopActiveAudio();
        final int myGen = playbackGeneration.incrementAndGet();

        Thread worker = new Thread(() -> {
            while (playbackGeneration.get() == myGen && config.musicEnabled) {
                List<Path> tracks = listLocalMusicFiles();
                if (tracks.isEmpty()) {
                    currentTrackLabel = "Folder music trống";
                    break;
                }

                if (currentLocalTrackIndex < 0 || currentLocalTrackIndex >= tracks.size()) {
                    currentLocalTrackIndex = 0;
                }

                Path track = tracks.get(currentLocalTrackIndex);
                currentLocalTrackIndex = (currentLocalTrackIndex + 1) % tracks.size();

                String fileName = track.getFileName().toString();
                String lower = fileName.toLowerCase(Locale.ROOT);
                currentTrackLabel = fileName;

                if (client != null) {
                    client.execute(() -> notifyPlayer(client, "§d♪ Đang phát: §f" + fileName));
                }

                if (lower.endsWith(".mp3")) {
                    playMp3Blocking(track, myGen);
                } else if (lower.endsWith(".wav")) {
                    playWavBlocking(track, myGen);
                } else {
                    try {
                        Util.getOperatingSystem().open(track.toFile());
                    } catch (Exception ignored) {
                    }
                    break;
                }

                if (playbackGeneration.get() == myGen) {
                    try {
                        Thread.sleep(1200L);
                    } catch (InterruptedException e) {
                        break;
                    }
                }
            }
        }, "AutoBuild-Music-Thread-" + myGen);

        worker.setDaemon(true);
        activeWorkerThread = worker;
        worker.start();
    }

    private void playMp3Blocking(Path track, int myGen) {
        Player mp3Player = null;
        try (InputStream fileIn = Files.newInputStream(track);
             BufferedInputStream bufferedIn = new BufferedInputStream(fileIn)) {
            if (playbackGeneration.get() != myGen) {
                return;
            }
            mp3Player = new Player(bufferedIn);
            synchronized (audioLock) {
                if (playbackGeneration.get() != myGen) {
                    mp3Player.close();
                    return;
                }
                activeMp3Player = mp3Player;
            }
            mp3Player.play();
        } catch (Exception ignored) {
        } finally {
            synchronized (audioLock) {
                if (activeMp3Player == mp3Player) {
                    activeMp3Player = null;
                }
            }
            if (mp3Player != null) {
                try {
                    mp3Player.close();
                } catch (Exception ignored) {
                }
            }
        }
    }

    private void playWavBlocking(Path track, int myGen) {
        Clip clip = null;
        try (AudioInputStream rawIn = AudioSystem.getAudioInputStream(track.toFile())) {
            AudioFormat baseFormat = rawIn.getFormat();
            AudioFormat decodedFormat = new AudioFormat(
                    AudioFormat.Encoding.PCM_SIGNED,
                    baseFormat.getSampleRate(),
                    16,
                    baseFormat.getChannels(),
                    baseFormat.getChannels() * 2,
                    baseFormat.getSampleRate(),
                    false
            );

            try (AudioInputStream pcmIn = AudioSystem.getAudioInputStream(decodedFormat, rawIn)) {
                if (playbackGeneration.get() != myGen) {
                    return;
                }
                clip = AudioSystem.getClip();
                CountDownLatch stopLatch = new CountDownLatch(1);
                clip.addLineListener(event -> {
                    if (event.getType() == LineEvent.Type.STOP || event.getType() == LineEvent.Type.CLOSE) {
                        stopLatch.countDown();
                    }
                });

                clip.open(pcmIn);
                synchronized (audioLock) {
                    if (playbackGeneration.get() != myGen) {
                        clip.close();
                        return;
                    }
                    activeWavClip = clip;
                }

                clip.start();

                while (playbackGeneration.get() == myGen && !stopLatch.await(250, TimeUnit.MILLISECONDS)) {
                    if (!clip.isOpen()) {
                        break;
                    }
                }
            }
        } catch (Exception ignored) {
        } finally {
            synchronized (audioLock) {
                if (activeWavClip == clip) {
                    activeWavClip = null;
                }
            }
            if (clip != null) {
                try {
                    clip.stop();
                    clip.close();
                } catch (Exception ignored) {
                }
            }
        }
    }

    public void openYoutubeLinkInBrowser(MinecraftClient client, String rawUrl) {
        long now = System.currentTimeMillis();
        if (now - lastBrowserOpenEpochMs < 3000L) {
            return;
        }
        lastBrowserOpenEpochMs = now;

        String url = (rawUrl != null) ? rawUrl.trim() : "";
        if (url.isEmpty()) {
            notifyPlayer(client, "§cChưa nhập link YouTube trong Menu AutoBuild!");
            return;
        }
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "https://" + url;
        }

        try {
            URI uri = URI.create(url);
            Util.getOperatingSystem().open(uri);
            currentTrackLabel = "YouTube Browser";
            notifyPlayer(client, "§d♪ Đã mở nhạc YouTube trên trình duyệt mặc định!");
        } catch (Exception e) {
            notifyPlayer(client, "§cLink YouTube không hợp lệ: " + url);
        }
    }

    public List<Path> listLocalMusicFiles() {
        ensureMusicDirectoryExists();
        List<Path> result = new ArrayList<>();
        try (Stream<Path> stream = Files.list(MUSIC_DIR)) {
            stream.filter(Files::isRegularFile)
                    .filter(p -> {
                        String name = p.getFileName().toString().toLowerCase(Locale.ROOT);
                        return name.endsWith(".mp3") || name.endsWith(".wav")
                                || name.endsWith(".ogg") || name.endsWith(".flac");
                    })
                    .sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase(Locale.ROOT)))
                    .forEach(result::add);
        } catch (IOException ignored) {
        }
        return result;
    }

    public void openMusicFolder() {
        ensureMusicDirectoryExists();
        try {
            File folder = MUSIC_DIR.toFile();
            Util.getOperatingSystem().open(folder);
        } catch (Exception ignored) {
        }
    }

    public void stopActiveAudio() {
        playbackGeneration.incrementAndGet();
        currentTrackLabel = "Đã dừng";
        synchronized (audioLock) {
            if (activeMp3Player != null) {
                try {
                    activeMp3Player.close();
                } catch (Exception ignored) {
                }
                activeMp3Player = null;
            }
            if (activeWavClip != null) {
                try {
                    activeWavClip.stop();
                    activeWavClip.close();
                } catch (Exception ignored) {
                }
                activeWavClip = null;
            }
        }
        Thread worker = activeWorkerThread;
        if (worker != null) {
            worker.interrupt();
            activeWorkerThread = null;
        }
    }

    public String getCurrentTrackLabel() {
        return currentTrackLabel;
    }

    private void notifyPlayer(MinecraftClient client, String msg) {
        if (client != null && client.player != null) {
            client.player.sendMessage(Text.literal("§8[§bLitematica-AutoBuild§8] §r" + msg), true);
        }
    }
}
