package net.autobuild.litematica;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.Iterator;

/**
 * Quản lý việc tự động đào block đặt sai và thu hồi Block Kê tạm thời (v2.6):
 * - Không đào nhầm tấm Slab đơn khi bản vẽ yêu cầu Double Slab (để PlacementEngine đặt tiếp tấm thứ 2).
 * - Không đào mất Block Kê bắc cầu khi xung quanh bán kính 3 ô vẫn còn khối chưa xây xong.
 */
public class ExcavateAndWalkManager {

    private BlockPos currentMiningPos = null;

    public boolean tickExcavate(
            MinecraftClient client,
            World schematicWorld,
            PrinterConfig config,
            InventoryManager inventoryManager,
            ScaffoldPlanner scaffoldPlanner
    ) {
        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        ClientPlayerInteractionManager interactionManager = client.interactionManager;
        if (player == null || world == null || interactionManager == null) {
            return false;
        }

        Vec3d eyePos = player.getEyePos();
        BlockPos playerPos = player.getBlockPos();
        int radius = (int) Math.ceil(config.maxReachDistance);
        double maxReachSq = config.maxReachDistance * config.maxReachDistance;

        BlockPos bestMinePos = null;
        double bestDistSq = Double.MAX_VALUE;

        if (config.autoExcavateWrongBlocks) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dx = -radius; dx <= radius; dx++) {
                    for (int dz = -radius; dz <= radius; dz++) {
                        BlockPos pos = playerPos.add(dx, dy, dz);
                        double distSq = eyePos.squaredDistanceTo(Vec3d.ofCenter(pos));
                        if (distSq > maxReachSq || !LitematicaBridge.isWithinLayerRange(pos)) {
                            continue;
                        }

                        BlockState schematicState = schematicWorld.getBlockState(pos);
                        BlockState worldState = world.getBlockState(pos);

                        if (worldState.isAir() || !worldState.getFluidState().isEmpty() || schematicState.isAir()) {
                            continue;
                        }
                        if (!config.isBlockAllowed(schematicState.getBlock())) {
                            continue;
                        }
                        // Nếu đây là nửa đầu của Double Slab đang chờ ghép thêm tấm thứ 2 thì tuyệt đối không đào!
                        if (PlacementEngine.isTargetNeedingPlacement(worldState, schematicState)) {
                            continue;
                        }
                        if (!SchematicAnalyzer.isStateMatching(worldState, schematicState)
                                && worldState.getHardness(world, pos) >= 0) {
                            if (distSq < bestDistSq) {
                                bestDistSq = distSq;
                                bestMinePos = pos;
                            }
                        }
                    }
                }
            }
        }

        if (bestMinePos == null && config.autoRecycleScaffolds) {
            Iterator<BlockPos> it = scaffoldPlanner.getPlacedTemporaryScaffolds().iterator();
            while (it.hasNext()) {
                BlockPos scaffPos = it.next();
                BlockState worldState = world.getBlockState(scaffPos);
                if (worldState.isAir()) {
                    it.remove();
                    continue;
                }
                if (scaffPos.equals(playerPos.down())) {
                    continue;
                }
                double distSq = eyePos.squaredDistanceTo(Vec3d.ofCenter(scaffPos));
                if (distSq <= maxReachSq && !isStillNeededForNearbyUnbuilt(world, schematicWorld, scaffPos)) {
                    bestMinePos = scaffPos;
                    break;
                }
            }
        }

        if (bestMinePos != null) {
            BlockState targetState = world.getBlockState(bestMinePos);
            if (config.autoSwitchBestTool) {
                inventoryManager.selectBestMiningTool(player, targetState);
            }

            Vec3d center = Vec3d.ofCenter(bestMinePos);
            float[] angles = PlacementEngine.computeAnglesForState(eyePos, center, targetState);
            PlacementEngine.applySmoothRotation(player, angles[0], angles[1], config.maxRotationStep, config.smoothHumanRotationCurve);

            currentMiningPos = bestMinePos;
            interactionManager.updateBlockBreakingProgress(bestMinePos, Direction.UP);
            player.swingHand(Hand.MAIN_HAND);
            return true;
        }

        cancelMining(client);
        return false;
    }

    private boolean isStillNeededForNearbyUnbuilt(ClientWorld world, World schematicWorld, BlockPos scaffPos) {
        for (int dy = 0; dy <= 2; dy++) {
            for (int dx = -3; dx <= 3; dx++) {
                for (int dz = -3; dz <= 3; dz++) {
                    BlockPos check = scaffPos.add(dx, dy, dz);
                    BlockState schem = schematicWorld.getBlockState(check);
                    if (!schem.isAir() && schem.getFluidState().isEmpty() && world.getBlockState(check).isReplaceable()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public void cancelMining(MinecraftClient client) {
        if (currentMiningPos != null && client != null && client.interactionManager != null) {
            client.interactionManager.cancelBlockBreaking();
            currentMiningPos = null;
        }
    }
}
