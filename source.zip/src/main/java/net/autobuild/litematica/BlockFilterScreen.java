package net.autobuild.litematica;

import net.minecraft.block.Block;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Màn hình Quản Lý Bộ Lọc Whitelist / Blacklist Block (v2.5):
 * - Chuyển đổi giữa 3 chế độ: BLACKLIST (Chặn các block trong danh sách), WHITELIST (Chỉ đặt các block trong danh sách), hoặc NONE (Tắt lọc).
 * - Cho phép bấm trực tiếp vào các Block có trong bản vẽ Litematica hiện tại để Cho phép / Bỏ qua chỉ với 1 click!
 * - Có nút "Thêm/Gỡ Block Đang Cầm Trên Tay" và ô nhập ID block tùy ý (ví dụ: tnt, bedrock, obsidian).
 */
public class BlockFilterScreen extends Screen {

    private final Screen parent;
    private final PrinterConfig config;
    private final SchematicAnalyzer analyzer;
    private TextFieldWidget customBlockIdField;

    public BlockFilterScreen(Screen parent, PrinterConfig config, SchematicAnalyzer analyzer) {
        super(Text.literal("Litematica AutoBuild - Quản Lý Whitelist / Blacklist Block"));
        this.parent = parent;
        this.config = config;
        this.analyzer = analyzer;
    }

    @Override
    protected void init() {
        super.init();
        int topY = 28;
        int centerX = this.width / 2;

        // Nút chuyển chế độ lọc: BLACKLIST -> WHITELIST -> NONE
        this.addDrawableChild(ButtonWidget.builder(getFilterModeButtonText(), btn -> {
            if ("BLACKLIST".equalsIgnoreCase(config.blockFilterMode)) {
                config.blockFilterMode = "WHITELIST";
            } else if ("WHITELIST".equalsIgnoreCase(config.blockFilterMode)) {
                config.blockFilterMode = "NONE";
            } else {
                config.blockFilterMode = "BLACKLIST";
            }
            config.save();
            this.clearAndInit();
        }).dimensions(20, topY, 175, 20).build());

        // Nút thêm/gỡ nhanh Block đang cầm trên tay chính
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§e+ Thêm/Gỡ Block Đang Cầm"), btn -> {
            if (this.client != null && this.client.player != null) {
                ItemStack held = this.client.player.getMainHandStack();
                if (!held.isEmpty() && held.getItem() instanceof BlockItem blockItem) {
                    toggleBlockInActiveList(blockItem.getBlock());
                    this.clearAndInit();
                }
            }
        }).dimensions(200, topY, 160, 20).build());

        // Ô nhập ID Block tùy chỉnh (ví dụ: tnt, bedrock, cobblestone)
        this.customBlockIdField = new TextFieldWidget(
                this.textRenderer,
                20,
                topY + 26,
                215,
                18,
                Text.literal("Nhập ID block (vd: tnt, bedrock)")
        );
        this.customBlockIdField.setMaxLength(128);
        this.addDrawableChild(this.customBlockIdField);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("§a+ Thêm ID"), btn -> {
            String normalized = PrinterConfig.normalizeBlockId(this.customBlockIdField.getText());
            if (!normalized.isEmpty()) {
                List<String> targetList = getActiveEditableList();
                if (!targetList.contains(normalized)) {
                    targetList.add(normalized);
                    config.save();
                }
                this.customBlockIdField.setText("");
                this.clearAndInit();
            }
        }).dimensions(240, topY + 26, 65, 18).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("§cXóa Hết DS"), btn -> {
            getActiveEditableList().clear();
            config.save();
            this.clearAndInit();
        }).dimensions(310, topY + 26, 70, 18).build());

        // Cột Trái: Danh sách các Block có trong bản vẽ hiện tại (Bấm để Cho Phép / Chặn)
        List<Block> schemBlocks = new ArrayList<>(analyzer.getDistinctSchematicBlocks());
        int listStartY = 88;
        int col1X = 20;
        int maxRows = Math.min(8, (this.height - listStartY - 32) / 20);

        for (int i = 0; i < Math.min(schemBlocks.size(), maxRows); i++) {
            Block b = schemBlocks.get(i);
            boolean allowed = config.isBlockAllowed(b);
            String blockName = b.getName().getString();
            String statusPrefix = allowed ? "§a[ĐƯỢC ĐẶT] §f" : "§c[BỎ QUA] §7";
            this.addDrawableChild(ButtonWidget.builder(Text.literal(statusPrefix + blockName), btn -> {
                toggleBlockInActiveList(b);
                this.clearAndInit();
            }).dimensions(col1X + 20, listStartY + i * 20, 195, 18).build());
        }

        // Cột Phải: Các ID đang nằm trong danh sách Blacklist / Whitelist hiện tại (Bấm vào để xóa)
        List<String> currentList = getActiveEditableList();
        int col2X = 250;
        for (int i = 0; i < Math.min(currentList.size(), maxRows); i++) {
            String id = currentList.get(i);
            this.addDrawableChild(ButtonWidget.builder(Text.literal("§e" + id + " §c[Xóa]"), btn -> {
                currentList.remove(id);
                config.save();
                this.clearAndInit();
            }).dimensions(col2X, listStartY + i * 20, 190, 18).build());
        }

        this.addDrawableChild(ButtonWidget.builder(Text.literal("§a✔ Quay Lại Menu Chính"), btn -> this.close())
                .dimensions(centerX - 80, this.height - 24, 160, 18).build());
    }

    private List<String> getActiveEditableList() {
        if ("WHITELIST".equalsIgnoreCase(config.blockFilterMode)) {
            return config.whitelistedBlocks;
        }
        return config.blacklistedBlocks;
    }

    private void toggleBlockInActiveList(Block block) {
        String id = Registries.BLOCK.getId(block).toString();
        if ("NONE".equalsIgnoreCase(config.blockFilterMode)) {
            config.blockFilterMode = "BLACKLIST";
        }
        List<String> list = getActiveEditableList();
        if (list.contains(id)) {
            list.remove(id);
        } else {
            list.add(id);
        }
        config.save();
    }

    private Text getFilterModeButtonText() {
        if ("WHITELIST".equalsIgnoreCase(config.blockFilterMode)) {
            return Text.literal("Chế độ lọc: §aWHITELIST (Chỉ đặt)");
        }
        if ("NONE".equalsIgnoreCase(config.blockFilterMode)) {
            return Text.literal("Chế độ lọc: §7TẮT (Đặt tất cả)");
        }
        return Text.literal("Chế độ lọc: §cBLACKLIST (Chặn)");
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (this.customBlockIdField != null && this.customBlockIdField.isFocused()) {
            if (this.customBlockIdField.keyPressed(input)) {
                return true;
            }
        }
        return super.keyPressed(input);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        context.fill(0, 0, this.width, this.height, 0xD80A0E15);
        super.render(context, mouseX, mouseY, deltaTicks);

        context.drawCenteredTextWithShadow(
                this.textRenderer,
                Text.literal("§b§lQUẢN LÝ WHITELIST / BLACKLIST BLOCK §7— §fChọn Block Được Đặt Hoặc Bỏ Qua"),
                this.width / 2,
                10,
                0xFFFFFFFF
        );

        context.drawTextWithShadow(
                this.textRenderer,
                Text.literal("§e§lBlock Trong Bản Vẽ (Bấm để Đổi):"),
                20,
                75,
                0xFFFFFFFF
        );

        String rightTitle = "WHITELIST".equalsIgnoreCase(config.blockFilterMode)
                ? "§a§lDanh Sách Whitelist (Chỉ đặt các khối này):"
                : "§c§lDanh Sách Blacklist (Tuyệt đối không đặt):";
        context.drawTextWithShadow(this.textRenderer, Text.literal(rightTitle), 250, 75, 0xFFFFFFFF);

        // Vẽ icon 3D của các Block trong bản vẽ ở cột trái
        List<Block> schemBlocks = new ArrayList<>(analyzer.getDistinctSchematicBlocks());
        int listStartY = 88;
        int maxRows = Math.min(8, (this.height - listStartY - 32) / 20);
        for (int i = 0; i < Math.min(schemBlocks.size(), maxRows); i++) {
            Block b = schemBlocks.get(i);
            context.drawItem(new ItemStack(b.asItem()), 20, listStartY + i * 20 + 1);
        }
    }

    @Override
    public void close() {
        config.save();
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
