package net.autobuild.litematica;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * Hệ thống Lưu / Tải nhiều Profile cấu hình (Multi-Profile Manager v2.5):
 * Hỗ trợ chuyển nhanh giữa 5 bộ cài đặt:
 * 1. "DonutSMP An Toàn" (Xoay mượt 45°/t, Delay 2t, Tầm 4.25m, Khóa tầng, Auto /home, Bypass Anti-Cheat)
 * 2. "Creative Nhanh" (EasyPlace xoay 180°/t, Delay 1t, Tầm 5.0m, Xây tự do)
 * 3. "Survival Chậm" (Xoay siêu mượt 24°/t như người thật, Delay 4t, Tầm 4.0m, Cực kỳ an toàn)
 * 4. "Custom 1" (File JSON tự lưu tại config/litematica_autobuild/profiles/custom_1.json)
 * 5. "Custom 2" (File JSON tự lưu tại config/litematica_autobuild/profiles/custom_2.json)
 */
public final class ProfileManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PROFILES_DIR = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("litematica_autobuild")
            .resolve("profiles");

    public static final List<String> PROFILE_NAMES = List.of(
            "DonutSMP An Toàn",
            "Creative Nhanh",
            "Survival Chậm",
            "Custom 1",
            "Custom 2"
    );

    private ProfileManager() {
    }

    private static void ensureDirectory() {
        try {
            Files.createDirectories(PROFILES_DIR);
        } catch (IOException ignored) {
        }
    }

    public static void cycleAndLoadNextProfile(MinecraftClient client, PrinterConfig config) {
        int idx = PROFILE_NAMES.indexOf(config.activeProfileName);
        int nextIdx = (idx + 1) % PROFILE_NAMES.size();
        String nextProfile = PROFILE_NAMES.get(nextIdx);
        applyProfile(client, config, nextProfile);
    }

    public static void applyProfile(MinecraftClient client, PrinterConfig config, String profileName) {
        ensureDirectory();
        config.activeProfileName = profileName;

        if ("DonutSMP An Toàn".equals(profileName)) {
            config.antiCheatStrictMode = true;
            config.strictLayerByLayer = true;
            config.autoScaffoldEnabled = true;
            config.autoRecycleScaffolds = true;
            config.autoExcavateWrongBlocks = true;
            config.autoStopWhenOutOfMaterials = true;
            config.autoHomeWhenStuck = true;
            config.placeDelayTicks = 2;
            config.maxReachDistance = 4.25;
            config.maxRotationStep = 45.0f;
            config.smoothHumanRotationCurve = true;
            config.save();
            notify(client, "§aĐã nạp Profile: §eDonutSMP An Toàn §7(Xoay 45°/t, Delay 2t, Tầm 4.25m)");
            return;
        }

        if ("Creative Nhanh".equals(profileName)) {
            config.antiCheatStrictMode = false;
            config.strictLayerByLayer = false;
            config.autoScaffoldEnabled = true;
            config.autoRecycleScaffolds = false;
            config.autoExcavateWrongBlocks = true;
            config.autoStopWhenOutOfMaterials = false;
            config.autoHomeWhenStuck = false;
            config.placeDelayTicks = 1;
            config.maxReachDistance = 5.0;
            config.maxRotationStep = 180.0f;
            config.smoothHumanRotationCurve = false;
            config.save();
            notify(client, "§bĐã nạp Profile: §fCreative Nhanh §7(EasyPlace 180°/t, Delay 1t, Tầm 5.0m)");
            return;
        }

        if ("Survival Chậm".equals(profileName)) {
            config.antiCheatStrictMode = true;
            config.strictLayerByLayer = true;
            config.autoScaffoldEnabled = true;
            config.autoRecycleScaffolds = true;
            config.autoExcavateWrongBlocks = true;
            config.autoStopWhenOutOfMaterials = true;
            config.autoHomeWhenStuck = true;
            config.placeDelayTicks = 4;
            config.maxReachDistance = 4.00;
            config.maxRotationStep = 24.0f;
            config.smoothHumanRotationCurve = true;
            config.save();
            notify(client, "§aĐã nạp Profile: §2Survival Chậm §7(Siêu mượt 24°/t, Delay 4t, Tầm 4.0m)");
            return;
        }

        // Tải từ file Custom 1 hoặc Custom 2
        Path file = getCustomProfilePath(profileName);
        if (Files.exists(file)) {
            try (Reader reader = Files.newBufferedReader(file)) {
                PrinterConfig loaded = GSON.fromJson(reader, PrinterConfig.class);
                if (loaded != null) {
                    boolean keepPrinterState = config.printerEnabled;
                    config.copySettingsFrom(loaded);
                    config.printerEnabled = keepPrinterState;
                    config.activeProfileName = profileName;
                    config.save();
                    notify(client, "§dĐã tải cấu hình riêng: §f" + profileName);
                    return;
                }
            } catch (IOException ignored) {
            }
        }

        // Nếu file Custom chưa tồn tại, lưu cấu hình hiện tại vào file đó luôn
        saveCurrentToCustomProfile(client, config, profileName);
    }

    public static void saveCurrentToCustomProfile(MinecraftClient client, PrinterConfig config, String targetSlotName) {
        ensureDirectory();
        String slot = (targetSlotName != null && targetSlotName.startsWith("Custom"))
                ? targetSlotName
                : "Custom 1";
        Path file = getCustomProfilePath(slot);
        try (Writer writer = Files.newBufferedWriter(file)) {
            GSON.toJson(config, writer);
            config.activeProfileName = slot;
            config.save();
            notify(client, "§a✔ Đã lưu toàn bộ cài đặt hiện tại vào §e" + slot + "§a!");
        } catch (IOException ignored) {
        }
    }

    private static Path getCustomProfilePath(String profileName) {
        String safeName = profileName.toLowerCase().replace(" ", "_") + ".json";
        return PROFILES_DIR.resolve(safeName);
    }

    private static void notify(MinecraftClient client, String msg) {
        if (client != null && client.player != null) {
            client.player.sendMessage(Text.literal("§8[§bLitematica-AutoBuild§8] §r" + msg), true);
        }
    }
}
