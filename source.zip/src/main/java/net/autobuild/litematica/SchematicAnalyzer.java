package net.autobuild.litematica;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Bộ phân tích bản vẽ Litematica (v2.5):
 * 1. Áp dụng bộ lọc Whitelist / Blacklist: Bỏ qua các block bị chặn để không làm kẹt tiến trình khóa tầng Y.
 * 2. Phát hiện chính xác khi HẾT VẬT LIỆU (Out of Materials): Khi vẫn còn khối cần xây nhưng trong cả
 *    Hotbar + Inventory không còn bất kỳ vật phẩm nào phù hợp, phát tín hiệu để AutoBuild tự dừng và báo Chat.
 */
public class SchematicAnalyzer {

    public enum CellStatus {
        BUILT_CORRECT,
        UNBUILT,
        WRONG_BLOCK,
        FILTERED_OUT
    }

    public record PreviewCell(
            BlockPos pos,
            BlockState schematicState,
            Item item,
            ItemStack renderStack,
            CellStatus status
    ) {}

    private Integer activeLayerY = null;
    private int activeLayerRemainingCount = 0;
    private int totalSchematicBlocks = 0;
    private int builtSchematicBlocks = 0;
    private int wrongSchematicBlocks = 0;
    private int unbuiltAllowedCount = 0;
    private int unbuiltAvailableInInvCount = 0;
    private int minSchematicY = 0;
    private int maxSchematicY = 0;
    private BlockPos schematicCenterPos = null;
    private String lastMissingItemHint = "";
    private String missingItemsSummary = "";

    private final List<PreviewCell> cachedPreviewCells = new ArrayList<>();
    private final Map<Item, Integer> missingMaterialCounts = new HashMap<>();
    private final Set<Block> distinctSchematicBlocks = new LinkedHashSet<>();
    private int scanTickCounter = 0;

    public void reset() {
        activeLayerY = null;
        activeLayerRemainingCount = 0;
        totalSchematicBlocks = 0;
        builtSchematicBlocks = 0;
        wrongSchematicBlocks = 0;
        unbuiltAllowedCount = 0;
        unbuiltAvailableInInvCount = 0;
        schematicCenterPos = null;
        lastMissingItemHint = "";
        missingItemsSummary = "";
        cachedPreviewCells.clear();
        missingMaterialCounts.clear();
        distinctSchematicBlocks.clear();
    }

    public void updateAnalysis(
            MinecraftClient client,
            World schematicWorld,
            PrinterConfig config,
            InventoryManager inventoryManager,
            boolean forceImmediate
    ) {
        scanTickCounter++;
        if (!forceImmediate && scanTickCounter % 4 != 0 && activeLayerY != null) {
            return;
        }

        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        if (player == null || world == null || schematicWorld == null) {
            reset();
            return;
        }

        BlockPos center = player.getBlockPos();
        int radius = Math.max(24, Math.min(config.layerScanRadius, 64));
        int vertRadius = 24;

        Integer lowestAnyUnbuiltY = null;
        Map<Integer, Integer> unbuiltCountByY = new HashMap<>();
        Map<Integer, Integer> availableCountByY = new HashMap<>();
        Map<Integer, Item> missingItemByY = new HashMap<>();

        int total = 0;
        int built = 0;
        int wrong = 0;
        int totalUnbuiltAllowed = 0;
        int totalUnbuiltWithInv = 0;
        int minY = Integer.MAX_VALUE;
        int maxY = Integer.MIN_VALUE;
        long sumX = 0;
        long sumY = 0;
        long sumZ = 0;

        cachedPreviewCells.clear();
        missingMaterialCounts.clear();
        distinctSchematicBlocks.clear();

        for (int dy = -vertRadius; dy <= vertRadius; dy++) {
            int y = center.getY() + dy;
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    BlockPos pos = new BlockPos(center.getX() + dx, y, center.getZ() + dz);
                    if (!LitematicaBridge.isWithinLayerRange(pos)) {
                        continue;
                    }

                    BlockState schemState = schematicWorld.getBlockState(pos);
                    if (schemState.isAir() || !schemState.getFluidState().isEmpty()) {
                        continue;
                    }

                    Block block = schemState.getBlock();
                    Item item = block.asItem();
                    if (item == Items.AIR) {
                        continue;
                    }

                    distinctSchematicBlocks.add(block);
                    sumX += pos.getX();
                    sumY += pos.getY();
                    sumZ += pos.getZ();
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;

                    // Kiểm tra Whitelist / Blacklist
                    if (!config.isBlockAllowed(block)) {
                        if (cachedPreviewCells.size() < 2800) {
                            cachedPreviewCells.add(new PreviewCell(pos, schemState, item, new ItemStack(item), CellStatus.FILTERED_OUT));
                        }
                        continue;
                    }

                    total++;
                    BlockState worldState = world.getBlockState(pos);
                    CellStatus status;

                    if (isStateMatching(worldState, schemState)) {
                        built++;
                        status = CellStatus.BUILT_CORRECT;
                    } else if (PlacementEngine.isTargetNeedingPlacement(worldState, schemState)) {
                        status = CellStatus.UNBUILT;
                        totalUnbuiltAllowed++;
                        unbuiltCountByY.merge(y, 1, Integer::sum);
                        missingMaterialCounts.merge(item, 1, Integer::sum);

                        if (lowestAnyUnbuiltY == null || y < lowestAnyUnbuiltY) {
                            lowestAnyUnbuiltY = y;
                        }
                        if (inventoryManager.hasItemAvailable(player, item)) {
                            totalUnbuiltWithInv++;
                            availableCountByY.merge(y, 1, Integer::sum);
                        } else {
                            missingItemByY.putIfAbsent(y, item);
                        }
                    } else {
                        wrong++;
                        status = CellStatus.WRONG_BLOCK;
                        unbuiltCountByY.merge(y, 1, Integer::sum);
                        if (lowestAnyUnbuiltY == null || y < lowestAnyUnbuiltY) {
                            lowestAnyUnbuiltY = y;
                        }
                    }

                    if (cachedPreviewCells.size() < 2800) {
                        cachedPreviewCells.add(new PreviewCell(pos, schemState, item, new ItemStack(item), status));
                    }
                }
            }
        }

        int denom = Math.max(1, total);
        this.totalSchematicBlocks = total;
        this.builtSchematicBlocks = built;
        this.wrongSchematicBlocks = wrong;
        this.unbuiltAllowedCount = totalUnbuiltAllowed;
        this.minSchematicY = (minY == Integer.MAX_VALUE) ? center.getY() : minY;
        this.maxSchematicY = (maxY == Integer.MIN_VALUE) ? center.getY() : maxY;
        this.schematicCenterPos = (total > 0)
                ? new BlockPos((int) (sumX / denom), (int) (sumY / denom), (int) (sumZ / denom))
                : center;

        this.activeLayerY = lowestAnyUnbuiltY;
        this.activeLayerRemainingCount = (lowestAnyUnbuiltY != null)
                ? unbuiltCountByY.getOrDefault(lowestAnyUnbuiltY, 0)
                : 0;

        if (config.strictLayerByLayer && lowestAnyUnbuiltY != null) {
            this.unbuiltAvailableInInvCount = availableCountByY.getOrDefault(lowestAnyUnbuiltY, 0);
        } else {
            this.unbuiltAvailableInInvCount = totalUnbuiltWithInv;
        }

        Item missingOnActiveLayer = (lowestAnyUnbuiltY != null) ? missingItemByY.get(lowestAnyUnbuiltY) : null;
        this.lastMissingItemHint = (missingOnActiveLayer != null)
                ? missingOnActiveLayer.getName().getString()
                : "";

        // Tổng hợp danh sách các block đang thiếu để báo lên Chat khi tự động dừng
        List<Map.Entry<Item, Integer>> sortedMissing = new ArrayList<>(missingMaterialCounts.entrySet());
        sortedMissing.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        StringBuilder sb = new StringBuilder();
        int listed = 0;
        for (Map.Entry<Item, Integer> e : sortedMissing) {
            if (!inventoryManager.hasItemAvailable(player, e.getKey())) {
                if (listed > 0) sb.append(", ");
                sb.append(e.getKey().getName().getString()).append(" (x").append(e.getValue()).append(")");
                listed++;
                if (listed >= 3) break;
            }
        }
        this.missingItemsSummary = sb.length() > 0 ? sb.toString() : "Vật liệu xây dựng";
    }

    /**
     * Trả về true nếu bản vẽ (hoặc tầng đang khóa) vẫn còn khối chưa đặt (và không còn block sai cần đào),
     * nhưng trong cả Hotbar + Inventory của người chơi KHÔNG còn bất kỳ block nào để đặt tiếp!
     */
    public boolean isOutOfMaterialsForActiveBuild(PrinterConfig config) {
        if (config.strictLayerByLayer) {
            if (activeLayerY == null || activeLayerRemainingCount <= 0) {
                return false;
            }
            return wrongSchematicBlocks == 0 && unbuiltAvailableInInvCount == 0;
        }
        return unbuiltAllowedCount > 0 && wrongSchematicBlocks == 0 && unbuiltAvailableInInvCount == 0;
    }

    public boolean hasRemainingUnbuiltOnLayer(ClientWorld world, World schematicWorld, BlockPos center, int lockedY, int radius, PrinterConfig config) {
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                BlockPos pos = new BlockPos(center.getX() + dx, lockedY, center.getZ() + dz);
                if (!LitematicaBridge.isWithinLayerRange(pos)) {
                    continue;
                }
                BlockState schemState = schematicWorld.getBlockState(pos);
                if (schemState.isAir() || !schemState.getFluidState().isEmpty()) {
                    continue;
                }
                Block block = schemState.getBlock();
                if (block.asItem() == Items.AIR || !config.isBlockAllowed(block)) {
                    continue;
                }
                BlockState worldState = world.getBlockState(pos);
                if (!isStateMatching(worldState, schemState)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean isStateMatching(BlockState worldState, BlockState schematicState) {
        if (worldState.getBlock() != schematicState.getBlock()) {
            return false;
        }
        if (schematicState.contains(Properties.HORIZONTAL_FACING)
                && worldState.contains(Properties.HORIZONTAL_FACING)) {
            if (worldState.get(Properties.HORIZONTAL_FACING) != schematicState.get(Properties.HORIZONTAL_FACING)) {
                return false;
            }
        }
        if (schematicState.contains(Properties.FACING) && worldState.contains(Properties.FACING)) {
            if (worldState.get(Properties.FACING) != schematicState.get(Properties.FACING)) {
                return false;
            }
        }
        if (schematicState.contains(Properties.HOPPER_FACING) && worldState.contains(Properties.HOPPER_FACING)) {
            if (worldState.get(Properties.HOPPER_FACING) != schematicState.get(Properties.HOPPER_FACING)) {
                return false;
            }
        }
        if (schematicState.contains(Properties.BLOCK_FACE) && worldState.contains(Properties.BLOCK_FACE)) {
            if (worldState.get(Properties.BLOCK_FACE) != schematicState.get(Properties.BLOCK_FACE)) {
                return false;
            }
        }
        if (schematicState.contains(Properties.BLOCK_HALF) && worldState.contains(Properties.BLOCK_HALF)) {
            if (worldState.get(Properties.BLOCK_HALF) != schematicState.get(Properties.BLOCK_HALF)) {
                return false;
            }
        }
        if (schematicState.contains(Properties.SLAB_TYPE) && worldState.contains(Properties.SLAB_TYPE)) {
            if (worldState.get(Properties.SLAB_TYPE) != schematicState.get(Properties.SLAB_TYPE)) {
                return false;
            }
        }
        if (schematicState.contains(Properties.AXIS) && worldState.contains(Properties.AXIS)) {
            if (worldState.get(Properties.AXIS) != schematicState.get(Properties.AXIS)) {
                return false;
            }
        }
        return true;
    }

    public Integer getActiveLayerY() {
        return activeLayerY;
    }

    public int getActiveLayerRemainingCount() {
        return activeLayerRemainingCount;
    }

    public int getTotalSchematicBlocks() {
        return totalSchematicBlocks;
    }

    public int getBuiltSchematicBlocks() {
        return builtSchematicBlocks;
    }

    public int getWrongSchematicBlocks() {
        return wrongSchematicBlocks;
    }

    public int getMinSchematicY() {
        return minSchematicY;
    }

    public int getMaxSchematicY() {
        return maxSchematicY;
    }

    public BlockPos getSchematicCenterPos() {
        return schematicCenterPos;
    }

    public String getLastMissingItemHint() {
        return lastMissingItemHint;
    }

    public String getMissingItemsSummary() {
        return missingItemsSummary;
    }

    public List<PreviewCell> getCachedPreviewCells() {
        return cachedPreviewCells;
    }

    public Map<Item, Integer> getMissingMaterialCounts() {
        return missingMaterialCounts;
    }

    public Set<Block> getDistinctSchematicBlocks() {
        return distinctSchematicBlocks;
    }
}
