package net.autobuild.litematica;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/**
 * Entrypoint chính (ClientModInitializer) của Litematica AutoBuild v2.6 (Minecraft 1.21.11 Fabric).
 * Sử dụng kiến trúc 2 pha:
 * - START_CLIENT_TICK: Xoay góc nhìn (Yaw/Pitch) + Chọn vật phẩm trên Hotbar để ClientPlayerEntity.tick()
 *   tự động gửi gói tin góc nhìn chuẩn lên Server ở giữa tick.
 * - END_CLIENT_TICK: Thực thi interactBlock() ngay sau khi gói tin góc nhìn đã được gửi đi, đảm bảo
 *   100% các khối có hướng (Stairs, Repeater, Piston, Observer, Hopper...) không bao giờ bị đặt ngược!
 */
public class LitematicaAutoBuildClient implements ClientModInitializer {

    public static final String MOD_ID = "litematica_autobuild";

    private static final KeyBinding.Category KEY_CATEGORY =
            KeyBinding.Category.create(Identifier.of(MOD_ID, "general"));

    private static KeyBinding togglePrinterKey;
    private static KeyBinding openMenuKey;
    private static KeyBinding toggleModeKey;
    private static KeyBinding toggleLayerLockKey;
    private static KeyBinding toggleScaffoldKey;
    private static KeyBinding toggleExcavateKey;
    private static KeyBinding toggleAutoWalkKey;
    private static KeyBinding cycleDelayKey;
    private static KeyBinding toggleMusicKey;

    private PrinterConfig config;
    private InventoryManager inventoryManager;
    private SchematicAnalyzer schematicAnalyzer;
    private ScaffoldPlanner scaffoldPlanner;
    private PlacementEngine placementEngine;
    private ExcavateAndWalkManager excavateAndWalkManager;
    private SmartPathfinder smartPathfinder;
    private VisualGuideRenderer visualGuideRenderer;
    private MusicManager musicManager;

    private int tickCooldown = 0;
    private int outOfMaterialsTicks = 0;
    private Integer lastAnnouncedLayerY = null;

    @Override
    public void onInitializeClient() {
        SourceGuard.verifyRuntimeIntegrity();

        this.config = PrinterConfig.load();
        this.inventoryManager = new InventoryManager();
        this.schematicAnalyzer = new SchematicAnalyzer();
        this.scaffoldPlanner = new ScaffoldPlanner();
        this.placementEngine = new PlacementEngine();
        this.excavateAndWalkManager = new ExcavateAndWalkManager();
        this.smartPathfinder = new SmartPathfinder();
        this.visualGuideRenderer = new VisualGuideRenderer();
        this.musicManager = new MusicManager();

        togglePrinterKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.litematica_autobuild.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_CAPS_LOCK,
                KEY_CATEGORY
        ));

        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.litematica_autobuild.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KEY_CATEGORY
        ));

        toggleModeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.litematica_autobuild.mode",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_U,
                KEY_CATEGORY
        ));

        toggleLayerLockKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.litematica_autobuild.layer_lock",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_J,
                KEY_CATEGORY
        ));

        toggleScaffoldKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.litematica_autobuild.scaffold",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K,
                KEY_CATEGORY
        ));

        toggleExcavateKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.litematica_autobuild.excavate",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_I,
                KEY_CATEGORY
        ));

        toggleAutoWalkKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.litematica_autobuild.autowalk",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_O,
                KEY_CATEGORY
        ));

        cycleDelayKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.litematica_autobuild.delay",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_P,
                KEY_CATEGORY
        ));

        toggleMusicKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.litematica_autobuild.music",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_M,
                KEY_CATEGORY
        ));

        ClientTickEvents.START_CLIENT_TICK.register(this::onStartClientTick);
        ClientTickEvents.END_CLIENT_TICK.register(this::onEndClientTick);

        HudElementRegistry.addLast(
                Identifier.of(MOD_ID, "visual_guides"),
                (context, tickCounter) -> visualGuideRenderer.renderHud(
                        context,
                        tickCounter,
                        config,
                        schematicAnalyzer,
                        placementEngine,
                        smartPathfinder,
                        musicManager
                )
        );
    }

    private List<KeyBinding> getAllModKeyBindings() {
        return List.of(
                togglePrinterKey,
                openMenuKey,
                toggleModeKey,
                toggleLayerLockKey,
                toggleScaffoldKey,
                toggleExcavateKey,
                toggleAutoWalkKey,
                cycleDelayKey,
                toggleMusicKey
        );
    }

    private void openConfiguredMenu(MinecraftClient client) {
        Screen current = client.currentScreen;
        if ("MODERN".equalsIgnoreCase(config.menuStyle)) {
            client.setScreen(new ModernToggleMenuScreen(
                    current,
                    config,
                    schematicAnalyzer,
                    placementEngine,
                    smartPathfinder,
                    musicManager,
                    getAllModKeyBindings()
            ));
        } else {
            client.setScreen(new AutoBuildMenuScreen(
                    current,
                    config,
                    schematicAnalyzer,
                    placementEngine,
                    smartPathfinder,
                    musicManager,
                    getAllModKeyBindings()
            ));
        }
    }

    private void onStartClientTick(MinecraftClient client) {
        if (client.player == null || client.world == null || client.interactionManager == null) {
            resetAll(client);
            return;
        }

        handleKeyBindings(client);

        musicManager.tick(client, config);

        World schematicWorld = LitematicaBridge.getSchematicWorld();
        if (schematicWorld == null) {
            schematicAnalyzer.reset();
            return;
        }

        schematicAnalyzer.updateAnalysis(client, schematicWorld, config, inventoryManager, false);

        if (!config.printerEnabled) {
            outOfMaterialsTicks = 0;
            return;
        }

        // Tự động dừng khi hết vật liệu trong cả Hotbar + Inventory (tránh đứng đơ)
        if (config.autoStopWhenOutOfMaterials && !client.player.isCreative()) {
            if (schematicAnalyzer.isOutOfMaterialsForActiveBuild(config)) {
                outOfMaterialsTicks++;
                if (outOfMaterialsTicks >= 10) {
                    config.printerEnabled = false;
                    config.save();
                    resetAll(client);
                    musicManager.onMusicSettingChanged(client, config, false);
                    String missing = schematicAnalyzer.getMissingItemsSummary();
                    String chatMsg = "§8[§bLitematica-AutoBuild§8] §c§lĐÃ TỰ ĐỘNG DỪNG! §eHết vật liệu trong Hotbar & Túi đồ. Cần thêm: §f" + missing;
                    client.player.sendMessage(Text.literal(chatMsg), false);
                    client.player.sendMessage(Text.literal(chatMsg), true);
                    outOfMaterialsTicks = 0;
                    return;
                }
            } else {
                outOfMaterialsTicks = 0;
            }
        }

        if (client.currentScreen != null) {
            smartPathfinder.releaseWalkKeys(client, config);
            return;
        }

        smartPathfinder.tickStuckWatchdog(
                client,
                schematicWorld,
                config,
                placementEngine.getBlockedByHitboxPos()
        );

        Integer activeY = schematicAnalyzer.getActiveLayerY();
        if (config.strictLayerByLayer && activeY != null && !activeY.equals(lastAnnouncedLayerY)) {
            if (lastAnnouncedLayerY != null && activeY > lastAnnouncedLayerY) {
                sendStatus(client, "§aĐã xây xong tầng Y=" + lastAnnouncedLayerY + "! Chuyển lên tầng §eY=" + activeY);
            }
            lastAnnouncedLayerY = activeY;
        }

        inventoryManager.tick();
        placementEngine.tickCooldownMap(client.player);

        // Nếu đang xoay dở tới 1 khối từ tick trước, tiếp tục xoay trong START_CLIENT_TICK
        if (placementEngine.hasPendingTask()) {
            smartPathfinder.updateVisualTargetOnly(client, placementEngine.getCurrentHighlightedTarget());
            placementEngine.tickStartPendingRotation(client, config, inventoryManager);
            return;
        }

        if (tickCooldown > 0) {
            tickCooldown--;
            return;
        }

        // Tìm khối tiếp theo và xoay góc nhìn ngay trong START_CLIENT_TICK
        if (placementEngine.findAndScheduleNext(
                client,
                schematicWorld,
                config,
                inventoryManager,
                schematicAnalyzer,
                scaffoldPlanner
        )) {
            excavateAndWalkManager.cancelMining(client);
            smartPathfinder.updateVisualTargetOnly(client, placementEngine.getCurrentHighlightedTarget());
            return;
        }

        if (placementEngine.getBlockedByHitboxPos() != null) {
            smartPathfinder.stepBackFromBlockedTarget(
                    client,
                    schematicWorld,
                    placementEngine.getBlockedByHitboxPos(),
                    config
            );
            return;
        }

        if (excavateAndWalkManager.tickExcavate(client, schematicWorld, config, inventoryManager, scaffoldPlanner)) {
            smartPathfinder.releaseWalkKeys(client, config);
            return;
        }

        smartPathfinder.updateTargetsAndWalk(
                client,
                schematicWorld,
                config,
                inventoryManager,
                schematicAnalyzer
        );
    }

    /**
     * Pha 2 (END_CLIENT_TICK): Chạy ngay sau khi ClientPlayerEntity.sendMovementPackets() đã gửi gói tin
     * góc nhìn mới lên Server. Thực thi interactBlock() tại đây giúp Server nhận đúng 100% hướng của khối!
     */
    private void onEndClientTick(MinecraftClient client) {
        if (client.player == null || client.world == null || client.interactionManager == null) {
            return;
        }
        if (!config.printerEnabled || client.currentScreen != null) {
            return;
        }
        if (placementEngine.hasReadyEndTickTask()) {
            if (placementEngine.executeEndTickPlacement(client, config, inventoryManager, scaffoldPlanner)) {
                tickCooldown = config.placeDelayTicks;
            }
        }
    }

    private void handleKeyBindings(MinecraftClient client) {
        while (openMenuKey.wasPressed()) {
            openConfiguredMenu(client);
        }

        while (togglePrinterKey.wasPressed()) {
            config.printerEnabled = !config.printerEnabled;
            if (!config.printerEnabled) {
                resetAll(client);
            } else {
                schematicAnalyzer.updateAnalysis(client, LitematicaBridge.getSchematicWorld(), config, inventoryManager, true);
            }
            config.save();
            musicManager.onMusicSettingChanged(client, config, false);
            sendStatus(client, "AutoBuild: " + (config.printerEnabled ? "§aBẬT" : "§cTẮT")
                    + " §7| Profile: §e" + config.activeProfileName
                    + " §7| Xoay: §b" + Math.round(config.maxRotationStep) + "°/t");
        }

        while (toggleModeKey.wasPressed()) {
            config.antiCheatStrictMode = !config.antiCheatStrictMode;
            placementEngine.reset();
            config.save();
            sendStatus(client, "Chế độ xoay & đặt: "
                    + (config.antiCheatStrictMode ? "§eDonutSMP Anti-Cheat" : "§bEasyPlace"));
        }

        while (toggleLayerLockKey.wasPressed()) {
            config.strictLayerByLayer = !config.strictLayerByLayer;
            config.save();
            sendStatus(client, "Xây khóa theo từng tầng (Layer-by-Layer): "
                    + (config.strictLayerByLayer ? "§aBẬT" : "§cTẮT"));
        }

        while (toggleScaffoldKey.wasPressed()) {
            config.autoScaffoldEnabled = !config.autoScaffoldEnabled;
            config.save();
            sendStatus(client, "Tự đặt Block Kê: " + (config.autoScaffoldEnabled ? "§aBẬT" : "§cTẮT"));
        }

        while (toggleExcavateKey.wasPressed()) {
            config.autoExcavateWrongBlocks = !config.autoExcavateWrongBlocks;
            if (!config.autoExcavateWrongBlocks) {
                excavateAndWalkManager.cancelMining(client);
            }
            config.save();
            sendStatus(client, "Tự phá block đặt sai: " + (config.autoExcavateWrongBlocks ? "§aBẬT" : "§cTẮT"));
        }

        while (toggleAutoWalkKey.wasPressed()) {
            config.autoWalkEnabled = !config.autoWalkEnabled;
            if (!config.autoWalkEnabled) {
                smartPathfinder.releaseWalkKeys(client, config);
            }
            config.save();
            sendStatus(client, "Tự động tìm đường A*: " + (config.autoWalkEnabled ? "§aBẬT" : "§cTẮT"));
        }

        while (cycleDelayKey.wasPressed()) {
            config.placeDelayTicks = (config.placeDelayTicks % 5) + 1;
            config.save();
            sendStatus(client, "Tốc độ đặt block: §e" + config.placeDelayTicks + " tick(s)/block");
        }

        while (toggleMusicKey.wasPressed()) {
            config.musicEnabled = !config.musicEnabled;
            config.save();
            musicManager.onMusicSettingChanged(client, config, true);
            String sourceInfo = config.useLocalMusicFolder ? "MP3/WAV Local" : "YouTube";
            sendStatus(client, "§d♪ Nhạc khi AutoBuild: " + (config.musicEnabled ? "§aBẬT" : "§cTẮT")
                    + " §7(" + sourceInfo + ")");
        }
    }

    private void resetAll(MinecraftClient client) {
        placementEngine.reset();
        excavateAndWalkManager.cancelMining(client);
        smartPathfinder.reset(client, config);
        if (musicManager != null) {
            musicManager.stopActiveAudio();
        }
    }

    private void sendStatus(MinecraftClient client, String message) {
        if (client.player != null) {
            client.player.sendMessage(Text.literal("§8[§bLitematica-AutoBuild§8] §r" + message), true);
        }
    }
}
