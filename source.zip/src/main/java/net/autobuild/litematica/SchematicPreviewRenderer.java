package net.autobuild.litematica;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * Bộ vẽ Mô Hình 3D Bản Vẽ bằng BLOCK THẬT (Real Textured 3D Block Voxel Renderer).
 */
public final class SchematicPreviewRenderer {

    private SchematicPreviewRenderer() {
    }

    public static void renderRealBlock3DPreview(
            DrawContext context,
            TextRenderer textRenderer,
            SchematicAnalyzer analyzer,
            PlacementEngine placementEngine,
            int boxX,
            int boxY,
            int boxW,
            int boxH,
            int rotationIndex,
            Integer filterY,
            float zoomLevel,
            boolean hideBuiltBlocks
    ) {
        context.fill(boxX, boxY, boxX + boxW, boxY + boxH, 0xDF0D131D);
        context.drawStrokedRectangle(boxX, boxY, boxW, boxH, 0xFF00D8FF);

        List<SchematicAnalyzer.PreviewCell> cells = analyzer.getCachedPreviewCells();
        BlockPos origin = analyzer.getSchematicCenterPos();

        if (cells.isEmpty() || origin == null) {
            context.drawCenteredTextWithShadow(
                    textRenderer,
                    Text.literal("§7Chưa có bản vẽ Litematica trong vùng quét."),
                    boxX + boxW / 2,
                    boxY + boxH / 2 - 4,
                    0xFFAAAAAA
            );
            return;
        }

        BlockPos highlightTarget = placementEngine.getCurrentHighlightedTarget();
        int centerX = boxX + boxW / 2;
        int centerY = boxY + boxH / 2 + 10;

        int stepX = Math.max(4, Math.round(7.0f * zoomLevel));
        int stepZ = Math.max(2, Math.round(3.8f * zoomLevel));
        int stepY = Math.max(4, Math.round(7.5f * zoomLevel));

        List<SchematicAnalyzer.PreviewCell> visibleCells = new ArrayList<>();
        for (SchematicAnalyzer.PreviewCell cell : cells) {
            if (cell.status() == SchematicAnalyzer.CellStatus.FILTERED_OUT) {
                continue;
            }
            if (filterY != null && cell.pos().getY() != filterY) {
                continue;
            }
            if (hideBuiltBlocks && cell.status() == SchematicAnalyzer.CellStatus.BUILT_CORRECT) {
                continue;
            }
            visibleCells.add(cell);
        }

        visibleCells.sort(Comparator
                .<SchematicAnalyzer.PreviewCell>comparingInt(c -> c.pos().getY())
                .thenComparingInt(c -> {
                    int rx = c.pos().getX() - origin.getX();
                    int rz = c.pos().getZ() - origin.getZ();
                    for (int r = 0; r < rotationIndex; r++) {
                        int tmp = rx;
                        rx = -rz;
                        rz = tmp;
                    }
                    return rx + rz;
                }));

        int maxRenderCount = 520;
        int stride = Math.max(1, visibleCells.size() / maxRenderCount);

        for (int i = 0; i < visibleCells.size(); i += stride) {
            SchematicAnalyzer.PreviewCell cell = visibleCells.get(i);
            BlockPos pos = cell.pos();

            int rx = pos.getX() - origin.getX();
            int ry = pos.getY() - origin.getY();
            int rz = pos.getZ() - origin.getZ();

            for (int r = 0; r < rotationIndex; r++) {
                int tmp = rx;
                rx = -rz;
                rz = tmp;
            }

            int isoX = centerX + (rx - rz) * stepX;
            int isoY = centerY + (rx + rz) * stepZ - ry * stepY;

            if (isoX < boxX + 12 || isoX > boxX + boxW - 12 || isoY < boxY + 20 || isoY > boxY + boxH - 26) {
                continue;
            }

            context.drawItem(cell.renderStack(), isoX - 8, isoY - 8);

            if (highlightTarget != null && highlightTarget.equals(pos)) {
                context.drawStrokedRectangle(isoX - 8, isoY - 8, 16, 16, 0xFF00FF66);
                context.fill(isoX - 2, isoY - 2, isoX + 2, isoY + 2, 0xFF00FF66);
            } else if (cell.status() == SchematicAnalyzer.CellStatus.WRONG_BLOCK) {
                context.drawStrokedRectangle(isoX - 7, isoY - 7, 14, 14, 0xFFFF3333);
            } else if (cell.status() == SchematicAnalyzer.CellStatus.BUILT_CORRECT && !hideBuiltBlocks) {
                context.fill(isoX + 3, isoY - 6, isoX + 6, isoY - 3, 0xCC00EE66);
            }
        }

        context.fill(boxX + 1, boxY + 1, boxX + boxW - 1, boxY + 16, 0xCC090D14);
        String stats = String.format("§aĐã xây: %d/%d §7| §bTầng khóa: Y=%s §7| §cSai: %d",
                analyzer.getBuiltSchematicBlocks(),
                analyzer.getTotalSchematicBlocks(),
                analyzer.getActiveLayerY() != null ? analyzer.getActiveLayerY() : "Xong",
                analyzer.getWrongSchematicBlocks());
        context.drawTextWithShadow(textRenderer, Text.literal(stats), boxX + 6, boxY + 4, 0xFFFFFFFF);

        context.fill(boxX + 1, boxY + boxH - 22, boxX + boxW - 1, boxY + boxH - 1, 0xCC090D14);
        int itemX = boxX + 6;
        int itemY = boxY + boxH - 19;
        context.drawTextWithShadow(textRenderer, Text.literal("§bCần:"), itemX, itemY + 4, 0xFFCCCCCC);
        itemX += 26;

        List<Map.Entry<Item, Integer>> materials = new ArrayList<>(analyzer.getMissingMaterialCounts().entrySet());
        materials.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));

        int shown = 0;
        for (Map.Entry<Item, Integer> entry : materials) {
            if (shown >= 6 || itemX + 36 > boxX + boxW) {
                break;
            }
            ItemStack stack = new ItemStack(entry.getKey());
            context.drawItem(stack, itemX, itemY);
            context.drawTextWithShadow(
                    textRenderer,
                    Text.literal("§f" + entry.getValue()),
                    itemX + 17,
                    itemY + 5,
                    0xFFFFFFFF
            );
            itemX += MathHelper.clamp(38, 34, 48);
            shown++;
        }
    }
}
