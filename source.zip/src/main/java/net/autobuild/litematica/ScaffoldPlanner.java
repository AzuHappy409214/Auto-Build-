package net.autobuild.litematica;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Queue;
import java.util.Set;

/**
 * Giải bài toán Đặt Block Kê (Auto-Scaffolding):
 * - Chỉ đặt block kê ở tầng <= floatingTarget.getY(), không bao giờ đặt vượt lên tầng trên.
 */
public class ScaffoldPlanner {

    public record ScaffoldCandidate(
            BlockPos scaffoldPos,
            BlockState desiredState,
            Item itemToUse,
            boolean isTemporaryScaffold
    ) {}

    private final Set<BlockPos> placedTemporaryScaffolds = new HashSet<>();

    public void clear() {
        placedTemporaryScaffolds.clear();
    }

    public void markTemporaryScaffold(BlockPos pos) {
        placedTemporaryScaffolds.add(pos.toImmutable());
    }

    public boolean isTemporaryScaffold(BlockPos pos) {
        return placedTemporaryScaffolds.contains(pos);
    }

    public void removeTemporaryScaffold(BlockPos pos) {
        placedTemporaryScaffolds.remove(pos);
    }

    public Set<BlockPos> getPlacedTemporaryScaffolds() {
        return placedTemporaryScaffolds;
    }

    public ScaffoldCandidate findBridgeScaffoldForFloatingTarget(
            MinecraftClient client,
            World schematicWorld,
            BlockPos floatingTarget,
            PrinterConfig config,
            InventoryManager inventoryManager
    ) {
        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        if (player == null || world == null) {
            return null;
        }

        Item scaffoldItem = inventoryManager.findAvailableScaffoldItem(player);
        if (scaffoldItem == null) {
            return null;
        }

        Vec3d eyePos = player.getEyePos();
        double maxReachSq = config.maxReachDistance * config.maxReachDistance;
        BlockState defaultScaffoldState = Block.getBlockFromItem(scaffoldItem).getDefaultState();

        Queue<BlockPos> queue = new ArrayDeque<>();
        Set<BlockPos> visited = new HashSet<>();

        queue.add(floatingTarget);
        visited.add(floatingTarget);

        Direction[] searchDirs = new Direction[]{
                Direction.DOWN,
                Direction.NORTH,
                Direction.SOUTH,
                Direction.EAST,
                Direction.WEST
        };

        BlockPos anchorNeighbor = null;
        int maxBfsNodes = 128;
        int steps = 0;

        while (!queue.isEmpty() && steps++ < maxBfsNodes) {
            BlockPos current = queue.poll();

            for (Direction dir : searchDirs) {
                BlockPos next = current.offset(dir);
                if (next.getY() > floatingTarget.getY() || next.getManhattanDistance(floatingTarget) > 8) {
                    continue;
                }

                BlockState nextWorldState = world.getBlockState(next);
                if (!nextWorldState.isAir() && !nextWorldState.isReplaceable()) {
                    if (!current.equals(floatingTarget)
                            && current.getY() <= floatingTarget.getY()
                            && world.getBlockState(current).isReplaceable()
                            && eyePos.squaredDistanceTo(Vec3d.ofCenter(current)) <= maxReachSq
                            && !SmartPathfinder.isPlayerIntersectingBlock(player, current)
                            && world.canPlace(defaultScaffoldState, current, ShapeContext.of(player))
                            && !current.equals(player.getBlockPos())
                            && !current.equals(player.getBlockPos().up())) {
                        anchorNeighbor = current;
                        break;
                    }
                } else if (visited.add(next)) {
                    queue.add(next);
                }
            }
            if (anchorNeighbor != null) {
                break;
            }
        }

        if (anchorNeighbor == null) {
            return null;
        }

        BlockState schemAtAnchor = schematicWorld.getBlockState(anchorNeighbor);
        if (!schemAtAnchor.isAir() && schemAtAnchor.getFluidState().isEmpty()
                && config.isBlockAllowed(schemAtAnchor.getBlock())
                && (!config.strictLayerByLayer || anchorNeighbor.getY() <= floatingTarget.getY())) {
            Item schemItem = schemAtAnchor.getBlock().asItem();
            if (schemItem != Items.AIR && inventoryManager.hasItemAvailable(player, schemItem)) {
                return new ScaffoldCandidate(anchorNeighbor, schemAtAnchor, schemItem, false);
            }
        }

        return new ScaffoldCandidate(anchorNeighbor, defaultScaffoldState, scaffoldItem, true);
    }
}
