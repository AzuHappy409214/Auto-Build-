package net.autobuild.litematica;

import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.lang.reflect.Method;

/**
 * Cầu nối giao tiếp với Litematica 1.21.11 (SchematicWorldHandler & DataManager).
 */
public final class LitematicaBridge {

    private static Method getSchematicWorldMethod;
    private static Method getRenderLayerRangeMethod;
    private static Method isPositionWithinRangeMethod;
    private static boolean initialized = false;

    private LitematicaBridge() {
    }

    private static void initReflection() {
        if (initialized) {
            return;
        }
        initialized = true;
        try {
            Class<?> handlerClass = Class.forName("fi.dy.masa.litematica.world.SchematicWorldHandler");
            getSchematicWorldMethod = handlerClass.getMethod("getSchematicWorld");

            Class<?> dataManagerClass = Class.forName("fi.dy.masa.litematica.data.DataManager");
            getRenderLayerRangeMethod = dataManagerClass.getMethod("getRenderLayerRange");

            Class<?> layerRangeClass = Class.forName("fi.dy.masa.litematica.util.LayerRange");
            isPositionWithinRangeMethod = layerRangeClass.getMethod("isPositionWithinRange", BlockPos.class);
        } catch (Exception ignored) {
        }
    }

    public static World getSchematicWorld() {
        initReflection();
        if (getSchematicWorldMethod == null) {
            return null;
        }
        try {
            Object worldObj = getSchematicWorldMethod.invoke(null);
            if (worldObj instanceof World world) {
                return world;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    public static boolean isWithinLayerRange(BlockPos pos) {
        initReflection();
        if (getRenderLayerRangeMethod == null || isPositionWithinRangeMethod == null) {
            return true;
        }
        try {
            Object rangeObj = getRenderLayerRangeMethod.invoke(null);
            if (rangeObj != null) {
                return (boolean) isPositionWithinRangeMethod.invoke(rangeObj, pos);
            }
        } catch (Exception ignored) {
        }
        return true;
    }
}
