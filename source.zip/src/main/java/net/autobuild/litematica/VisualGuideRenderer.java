package net.autobuild.litematica;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.List;

/**
 * Bộ vẽ đường chỉ dẫn trực quan 3D-to-2D & Bảng HUD góc trái trên (v2.5).
 */
public class VisualGuideRenderer {

    private static final int COLOR_GREEN_LINE = 0xFF00FF44;
    private static final int COLOR_GREEN_BOX = 0xCC00FF44;
    private static final int COLOR_CYAN_LINE = 0xFF00D8FF;
    private static final int COLOR_CYAN_BOX = 0xCC00D8FF;
    private static final int COLOR_PANEL_BG = 0x9010141C;
    private static final int COLOR_PANEL_BORDER = 0xFF00D8FF;

    public void renderHud(
            DrawContext context,
            RenderTickCounter tickCounter,
            PrinterConfig config,
            SchematicAnalyzer analyzer,
            PlacementEngine placementEngine,
            SmartPathfinder pathfinder,
            MusicManager musicManager
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        World schematicWorld = LitematicaBridge.getSchematicWorld();
        if (player == null || client.world == null || schematicWorld == null) {
            return;
        }

        int screenW = context.getScaledWindowWidth();
        int screenH = context.getScaledWindowHeight();
        int centerX = screenW / 2;
        int centerY = screenH / 2;

        if (config.renderVisualGuides && config.printerEnabled) {
            BlockPos nextBlock = placementEngine.getCurrentHighlightedTarget();
            if (nextBlock == null) {
                nextBlock = pathfinder.getNextTargetBlockPos();
            }
            BlockPos nextStand = pathfinder.getNextStandPos();

            if (nextStand != null) {
                Vec3d standCenter = new Vec3d(nextStand.getX() + 0.5, nextStand.getY() + 0.1, nextStand.getZ() + 0.5);
                int[] standScreen = project3DTo2D(client, player, standCenter, screenW, screenH);
                if (standScreen != null) {
                    int startX = centerX;
                    int startY = (int) (screenH * 0.78);

                    List<BlockPos> path = pathfinder.getCurrentPath();
                    int prevX = startX;
                    int prevY = startY;
                    for (BlockPos node : path) {
                        Vec3d nodeVec = new Vec3d(node.getX() + 0.5, node.getY() + 0.1, node.getZ() + 0.5);
                        int[] nodePt = project3DTo2D(client, player, nodeVec, screenW, screenH);
                        if (nodePt != null) {
                            drawThickLine(context, prevX, prevY, nodePt[0], nodePt[1], COLOR_CYAN_LINE);
                            prevX = nodePt[0];
                            prevY = nodePt[1];
                        }
                    }
                    drawThickLine(context, prevX, prevY, standScreen[0], standScreen[1], COLOR_CYAN_LINE);
                    drawProjectedBox3D(context, client, player, nextStand, 0.2, COLOR_CYAN_BOX, screenW, screenH);

                    double dist = Math.sqrt(player.getBlockPos().getSquaredDistance(nextStand));
                    String standLabel = String.format("Đứng tiếp: [%d, %d, %d] (%.1fm)",
                            nextStand.getX(), nextStand.getY(), nextStand.getZ(), dist);
                    context.drawTextWithShadow(
                            client.textRenderer,
                            Text.literal(standLabel),
                            MathHelper.clamp(standScreen[0] - 45, 6, screenW - 150),
                            MathHelper.clamp(standScreen[1] + 8, 6, screenH - 16),
                            COLOR_CYAN_LINE
                    );
                }
            }

            if (nextBlock != null) {
                Vec3d blockCenter = Vec3d.ofCenter(nextBlock);
                int[] blockScreen = project3DTo2D(client, player, blockCenter, screenW, screenH);
                if (blockScreen != null) {
                    drawThickLine(context, centerX, centerY, blockScreen[0], blockScreen[1], COLOR_GREEN_LINE);
                    drawProjectedBox3D(context, client, player, nextBlock, 1.0, COLOR_GREEN_BOX, screenW, screenH);

                    BlockState targetState = schematicWorld.getBlockState(nextBlock);
                    String blockName = targetState.getBlock().getName().getString();
                    String buildLabel = String.format("Xây tiếp: %s [%d, %d, %d]",
                            blockName, nextBlock.getX(), nextBlock.getY(), nextBlock.getZ());
                    context.drawTextWithShadow(
                            client.textRenderer,
                            Text.literal(buildLabel),
                            MathHelper.clamp(blockScreen[0] - 45, 6, screenW - 160),
                            MathHelper.clamp(blockScreen[1] - 14, 6, screenH - 16),
                            COLOR_GREEN_LINE
                    );
                }
            }
        }

        if (config.renderHudOverlay && client.currentScreen == null) {
            renderStatusPanel(context, client.textRenderer, config, analyzer, placementEngine, musicManager);
        }
    }

    private void renderStatusPanel(
            DrawContext context,
            TextRenderer textRenderer,
            PrinterConfig config,
            SchematicAnalyzer analyzer,
            PlacementEngine placementEngine,
            MusicManager musicManager
    ) {
        int x = 8;
        int y = 8;
        int w = 256;
        int h = 92;

        context.fill(x, y, x + w, y + h, COLOR_PANEL_BG);
        context.drawStrokedRectangle(x, y, w, h, COLOR_PANEL_BORDER);

        String stateStr = config.printerEnabled ? "§aĐANG BẬT" : "§cĐANG TẮT";
        context.drawTextWithShadow(
                textRenderer,
                Text.literal("§b§lAutoBuild v2.5 §7| " + stateStr + " §7(§e" + config.activeProfileName + "§7)"),
                x + 6, y + 6, 0xFFFFFFFF
        );

        Integer activeY = analyzer.getActiveLayerY();
        String layerInfo = (activeY != null)
                ? ("Tầng khóa: §aY = " + activeY + " §7(Còn §e" + analyzer.getActiveLayerRemainingCount() + "§7 khối)")
                : "Tầng khóa: §aĐã hoàn tất vùng quét!";
        context.drawTextWithShadow(textRenderer, Text.literal(layerInfo), x + 6, y + 19, 0xFFE0E0E0);

        int total = analyzer.getTotalSchematicBlocks();
        int built = analyzer.getBuiltSchematicBlocks();
        int pct = (total > 0) ? (built * 100 / total) : 0;
        String progressInfo = String.format("Tiến độ: §b%d/%d (%d%%) §7| Xoay: §e%d°/t §7| Lọc: §f%s",
                built, total, pct, Math.round(config.maxRotationStep), config.blockFilterMode);
        context.drawTextWithShadow(textRenderer, Text.literal(progressInfo), x + 6, y + 32, 0xFFE0E0E0);

        context.drawTextWithShadow(
                textRenderer,
                Text.literal("§eTrạng thái: §f" + placementEngine.getCurrentActionStatus()),
                x + 6, y + 45, 0xFFFFFFFF
        );

        String musicStatus = config.musicEnabled
                ? ("§aBẬT §7(" + (config.useLocalMusicFolder ? musicManager.getCurrentTrackLabel() : "YouTube") + ")")
                : "§7TẮT (Phím M)";
        context.drawTextWithShadow(
                textRenderer,
                Text.literal("§d♪ Nhạc: " + musicStatus),
                x + 6, y + 58, 0xFFFFFFFF
        );

        context.drawTextWithShadow(
                textRenderer,
                Text.literal("§7Nhấn §f[Right Shift]§7 mở Menu Cấu Hình & 3D"),
                x + 6, y + 72, 0xFFAAAAAA
        );
    }

    private int[] project3DTo2D(
            MinecraftClient client,
            ClientPlayerEntity player,
            Vec3d targetPos,
            int screenW,
            int screenH
    ) {
        Vec3d eyePos = player.getEyePos();
        double dx = targetPos.x - eyePos.x;
        double dy = targetPos.y - eyePos.y;
        double dz = targetPos.z - eyePos.z;

        double yawRad = Math.toRadians(player.getYaw());
        double pitchRad = Math.toRadians(player.getPitch());

        double camX = -dx * Math.cos(yawRad) - dz * Math.sin(yawRad);
        double horizZ = -dx * Math.sin(yawRad) + dz * Math.cos(yawRad);

        double camZ = horizZ * Math.cos(pitchRad) - dy * Math.sin(pitchRad);
        double camY = dy * Math.cos(pitchRad) + horizZ * Math.sin(pitchRad);

        double fovDeg = 70.0;
        if (client.options != null && client.options.getFov() != null) {
            fovDeg = client.options.getFov().getValue();
        }
        double focalLength = (screenH / 2.0) / Math.tan(Math.toRadians(fovDeg / 2.0));

        if (camZ <= 0.15) {
            double len = Math.sqrt(camX * camX + camY * camY);
            if (len < 0.001) {
                return new int[]{screenW / 2, screenH - 12, 0};
            }
            int edgeX = (int) (screenW / 2.0 + (camX / len) * (screenW * 0.42));
            int edgeY = (int) (screenH / 2.0 - (camY / len) * (screenH * 0.42));
            return new int[]{
                    MathHelper.clamp(edgeX, 10, screenW - 10),
                    MathHelper.clamp(edgeY, 10, screenH - 10),
                    0
            };
        }

        int sx = (int) (screenW / 2.0 + (camX / camZ) * focalLength);
        int sy = (int) (screenH / 2.0 - (camY / camZ) * focalLength);

        return new int[]{
                MathHelper.clamp(sx, 8, screenW - 8),
                MathHelper.clamp(sy, 8, screenH - 8),
                1
        };
    }

    private void drawProjectedBox3D(
            DrawContext context,
            MinecraftClient client,
            ClientPlayerEntity player,
            BlockPos pos,
            double boxHeight,
            int color,
            int screenW,
            int screenH
    ) {
        Vec3d center = new Vec3d(pos.getX() + 0.5, pos.getY() + boxHeight * 0.5, pos.getZ() + 0.5);
        int[] pt = project3DTo2D(client, player, center, screenW, screenH);
        if (pt == null || pt[2] == 0) {
            return;
        }
        double dist = Math.max(1.0, player.getEyePos().distanceTo(center));
        int halfSize = MathHelper.clamp((int) (26.0 / dist), 4, 18);
        context.drawStrokedRectangle(pt[0] - halfSize, pt[1] - halfSize, halfSize * 2, halfSize * 2, color);
        context.fill(pt[0] - 2, pt[1] - 2, pt[0] + 2, pt[1] + 2, color);
    }

    public static void drawThickLine(DrawContext context, int x0, int y0, int x1, int y1, int color) {
        int dx = x1 - x0;
        int dy = y1 - y0;
        int steps = Math.max(Math.abs(dx), Math.abs(dy));
        if (steps == 0) {
            context.fill(x0 - 1, y0 - 1, x0 + 2, y0 + 2, color);
            return;
        }
        int stepStride = Math.max(1, steps / 180);
        for (int i = 0; i <= steps; i += stepStride) {
            int px = x0 + (dx * i) / steps;
            int py = y0 + (dy * i) / steps;
            context.fill(px - 1, py - 1, px + 1, py + 1, color);
        }
    }
}
