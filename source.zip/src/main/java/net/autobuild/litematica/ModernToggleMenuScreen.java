package net.autobuild.litematica;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.KeybindsScreen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;

/**
 * Giao diện Menu Công Tắc Gạt (ModernToggleMenuScreen v2.5) đồng bộ đầy đủ Profile, Bộ lọc Block & Tốc độ xoay.
 */
public class ModernToggleMenuScreen extends Screen {

    private final Screen parent;
    private final PrinterConfig config;
    private final SchematicAnalyzer analyzer;
    private final PlacementEngine placementEngine;
    private final SmartPathfinder pathfinder;
    private final MusicManager musicManager;
    private final List<KeyBinding> modKeyBindings;

    private TextFieldWidget youtubeLinkField;
    private boolean show3DPreviewModal = false;
    private boolean hideBuiltIn3D = false;
    private int previewRotationIndex = 0;
    private Integer previewFilterY = null;
    private float previewZoom = 1.0f;

    private record MenuRow(
            String label,
            BooleanSupplier stateSupplier,
            String valueBadge,
            Runnable onLeftClick,
            Runnable onRightClick
    ) {}

    private record ClickHitbox(
            int x,
            int y,
            int w,
            int h,
            Runnable onLeftClick,
            Runnable onRightClick
    ) {}

    private final List<ClickHitbox> activeHitboxes = new ArrayList<>();

    public ModernToggleMenuScreen(
            Screen parent,
            PrinterConfig config,
            SchematicAnalyzer analyzer,
            PlacementEngine placementEngine,
            SmartPathfinder pathfinder,
            MusicManager musicManager,
            List<KeyBinding> modKeyBindings
    ) {
        super(Text.literal("Litematica AutoBuild - Toggle Menu"));
        this.parent = parent;
        this.config = config;
        this.analyzer = analyzer;
        this.placementEngine = placementEngine;
        this.pathfinder = pathfinder;
        this.musicManager = musicManager;
        this.modKeyBindings = modKeyBindings;
    }

    @Override
    protected void init() {
        super.init();
        if (this.client != null) {
            World schemWorld = LitematicaBridge.getSchematicWorld();
            analyzer.updateAnalysis(this.client, schemWorld, config, new InventoryManager(), true);
        }

        int barW = 240;
        int barX = this.width / 2 - barW / 2;
        int barY = this.height - 22;

        this.youtubeLinkField = new TextFieldWidget(
                this.textRenderer,
                barX,
                barY,
                barW,
                16,
                Text.literal("Link YouTube / Playlist")
        );
        this.youtubeLinkField.setMaxLength(512);
        this.youtubeLinkField.setText(config.youtubeLink != null ? config.youtubeLink : "");
        this.youtubeLinkField.setChangedListener(val -> {
            config.youtubeLink = val.trim();
        });
        this.addDrawableChild(this.youtubeLinkField);
    }

    private List<MenuRow> buildColumn1Rows() {
        List<MenuRow> rows = new ArrayList<>();
        rows.add(new MenuRow("AUTO BUILD", () -> config.printerEnabled, null, () -> {
            config.printerEnabled = !config.printerEnabled;
            config.save();
            musicManager.onMusicSettingChanged(this.client, config, false);
        }, null));
        rows.add(new MenuRow("DONUT BYPASS", () -> config.antiCheatStrictMode, null, () -> {
            config.antiCheatStrictMode = !config.antiCheatStrictMode;
            config.save();
        }, null));
        rows.add(new MenuRow("STRICT LAYER", () -> config.strictLayerByLayer, null, () -> {
            config.strictLayerByLayer = !config.strictLayerByLayer;
            config.save();
        }, null));
        rows.add(new MenuRow("AUTO SCAFFOLD", () -> config.autoScaffoldEnabled, null, () -> {
            config.autoScaffoldEnabled = !config.autoScaffoldEnabled;
            config.save();
        }, null));
        rows.add(new MenuRow("STOP NO MATS", () -> config.autoStopWhenOutOfMaterials, null, () -> {
            config.autoStopWhenOutOfMaterials = !config.autoStopWhenOutOfMaterials;
            config.save();
        }, null));
        rows.add(new MenuRow("BLOCK FILTER", null, config.blockFilterMode, () -> {
            if (this.client != null) {
                this.client.setScreen(new BlockFilterScreen(this, config, analyzer));
            }
        }, null));
        rows.add(new MenuRow("AUTO EXCAVATE", () -> config.autoExcavateWrongBlocks, null, () -> {
            config.autoExcavateWrongBlocks = !config.autoExcavateWrongBlocks;
            config.save();
        }, null));
        rows.add(new MenuRow("AUTO REPLENISH", () -> config.autoReplenishInventory, null, () -> {
            config.autoReplenishInventory = !config.autoReplenishInventory;
            config.save();
        }, null));
        return rows;
    }

    private List<MenuRow> buildColumn2Rows() {
        List<MenuRow> rows = new ArrayList<>();
        rows.add(new MenuRow("PROFILE", null, config.activeProfileName, () -> {
            ProfileManager.cycleAndLoadNextProfile(this.client, config);
        }, () -> {
            ProfileManager.saveCurrentToCustomProfile(this.client, config, "Custom 1");
        }));
        rows.add(new MenuRow("ROTATE SPEED", null, Math.round(config.maxRotationStep) + "°/t", () -> {
            config.maxRotationStep += 10.0f;
            if (config.maxRotationStep > 180.0f) config.maxRotationStep = 15.0f;
            config.save();
        }, () -> {
            config.maxRotationStep -= 10.0f;
            if (config.maxRotationStep < 10.0f) config.maxRotationStep = 180.0f;
            config.save();
        }));
        rows.add(new MenuRow("SMART WALK A*", () -> config.autoWalkEnabled, null, () -> {
            config.autoWalkEnabled = !config.autoWalkEnabled;
            config.save();
        }, null));
        rows.add(new MenuRow("UNSTUCK /HOME", () -> config.autoHomeWhenStuck, null, () -> {
            config.autoHomeWhenStuck = !config.autoHomeWhenStuck;
            config.save();
        }, null));
        rows.add(new MenuRow("HOME NUMBER", null, "/home " + config.stuckHomeNumber, () -> {
            config.stuckHomeNumber = (config.stuckHomeNumber % 15) + 1;
            config.save();
        }, () -> {
            config.stuckHomeNumber = config.stuckHomeNumber <= 1 ? 15 : config.stuckHomeNumber - 1;
            config.save();
        }));
        rows.add(new MenuRow("PLACE DELAY", null, config.placeDelayTicks + "t", () -> {
            config.placeDelayTicks = (config.placeDelayTicks % 5) + 1;
            config.save();
        }, null));
        rows.add(new MenuRow("REACH DIST", null, config.maxReachDistance + "m", () -> {
            double next = config.maxReachDistance + 0.25;
            if (next > 5.0) next = 3.75;
            config.maxReachDistance = Math.round(next * 100.0) / 100.0;
            config.save();
        }, null));
        return rows;
    }

    private List<MenuRow> buildColumn3Rows() {
        List<MenuRow> rows = new ArrayList<>();
        rows.add(new MenuRow("MUSIC PLAYER", () -> config.musicEnabled, null, () -> {
            if (this.youtubeLinkField != null && !this.youtubeLinkField.getText().isBlank()) {
                config.youtubeLink = this.youtubeLinkField.getText().trim();
            }
            config.musicEnabled = !config.musicEnabled;
            config.save();
            musicManager.onMusicSettingChanged(this.client, config, true);
        }, null));
        rows.add(new MenuRow("LOCAL MP3/WAV", () -> config.useLocalMusicFolder, null, () -> {
            config.useLocalMusicFolder = !config.useLocalMusicFolder;
            config.save();
            if (config.printerEnabled && config.musicEnabled) {
                musicManager.onMusicSettingChanged(this.client, config, true);
            }
        }, null));
        rows.add(new MenuRow("PASTE YT LINK", null, "CLIP", () -> {
            if (this.client != null && this.client.keyboard != null) {
                String clip = this.client.keyboard.getClipboard();
                if (clip != null && !clip.isBlank()) {
                    config.youtubeLink = clip.trim();
                    if (this.youtubeLinkField != null) {
                        this.youtubeLinkField.setText(config.youtubeLink);
                    }
                    config.save();
                }
            }
        }, null));
        rows.add(new MenuRow("PLAY / NEXT", null, "▶", () -> {
            if (this.youtubeLinkField != null && !this.youtubeLinkField.getText().isBlank()) {
                config.youtubeLink = this.youtubeLinkField.getText().trim();
            }
            config.save();
            musicManager.skipToNextLocalTrack(this.client, config);
        }, null));
        rows.add(new MenuRow("STOP AUDIO", null, "■", () -> {
            musicManager.stopActiveAudio();
        }, null));
        rows.add(new MenuRow("MUSIC FOLDER", null, musicManager.listLocalMusicFiles().size() + " bài", () -> {
            musicManager.openMusicFolder();
        }, null));
        return rows;
    }

    private List<MenuRow> buildColumn4Rows() {
        List<MenuRow> rows = new ArrayList<>();
        rows.add(new MenuRow("MENU NHƯ CŨ", null, "ĐỔI", () -> {
            config.menuStyle = "CLASSIC";
            config.save();
            if (this.client != null) {
                this.client.setScreen(new AutoBuildMenuScreen(
                        parent, config, analyzer, placementEngine, pathfinder, musicManager, modKeyBindings
                ));
            }
        }, null));
        rows.add(new MenuRow("HUD OVERLAY", () -> config.renderHudOverlay, null, () -> {
            config.renderHudOverlay = !config.renderHudOverlay;
            config.save();
        }, null));
        rows.add(new MenuRow("VISUAL GUIDES", () -> config.renderVisualGuides, null, () -> {
            config.renderVisualGuides = !config.renderVisualGuides;
            config.save();
        }, null));
        rows.add(new MenuRow("3D BLOCK MODEL", () -> show3DPreviewModal, null, () -> {
            show3DPreviewModal = !show3DPreviewModal;
        }, null));
        rows.add(new MenuRow("3D ROTATION", null, (previewRotationIndex * 90) + "°", () -> {
            previewRotationIndex = (previewRotationIndex + 1) % 4;
        }, null));
        rows.add(new MenuRow("3D ZOOM", null, String.format("%.1fx", previewZoom), () -> {
            previewZoom += 0.25f;
            if (previewZoom > 1.75f) previewZoom = 0.75f;
        }, null));
        rows.add(new MenuRow("KEYBINDS...", null, "OPEN", () -> {
            if (this.client != null) {
                this.client.setScreen(new KeybindsScreen(this, this.client.options));
            }
        }, null));
        return rows;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        context.fill(0, 0, this.width, this.height, 0xC8080B12);
        activeHitboxes.clear();

        context.drawCenteredTextWithShadow(
                this.textRenderer,
                Text.literal("§b§lLITEMATICA AUTOBUILD v2.5 §7— §fMenu Công Tắc Gạt (Bấm 'MENU NHƯ CŨ' để về Menu 3 Cột)"),
                this.width / 2,
                12,
                0xFFFFFFFF
        );

        int colW = 128;
        int gapX = 8;
        int totalW = colW * 4 + gapX * 3;
        int startX = Math.max(8, (this.width - totalW) / 2);
        int panelY = 34;

        renderCategoryColumn(context, startX, panelY, colW, "BUILD & FILTER", buildColumn1Rows(), mouseX, mouseY);
        renderCategoryColumn(context, startX + (colW + gapX), panelY, colW, "PROFILE & MOVE", buildColumn2Rows(), mouseX, mouseY);
        renderCategoryColumn(context, startX + (colW + gapX) * 2, panelY, colW, "MUSIC", buildColumn3Rows(), mouseX, mouseY);
        renderCategoryColumn(context, startX + (colW + gapX) * 3, panelY, colW, "RENDER & GUI", buildColumn4Rows(), mouseX, mouseY);

        if (show3DPreviewModal) {
            int modalW = Math.min(340, this.width - 40);
            int modalH = Math.min(185, this.height - 70);
            int modalX = (this.width - modalW) / 2;
            int modalY = (this.height - modalH) / 2 + 8;

            SchematicPreviewRenderer.renderRealBlock3DPreview(
                    context,
                    this.textRenderer,
                    analyzer,
                    placementEngine,
                    modalX,
                    modalY,
                    modalW,
                    modalH,
                    previewRotationIndex,
                    previewFilterY,
                    previewZoom,
                    hideBuiltIn3D
            );
        }

        super.render(context, mouseX, mouseY, deltaTicks);
    }

    private void renderCategoryColumn(
            DrawContext context,
            int x,
            int y,
            int w,
            String title,
            List<MenuRow> rows,
            int mouseX,
            int mouseY
    ) {
        int headerH = 18;
        int rowH = 19;
        int totalH = headerH + rows.size() * rowH + 3;

        context.fill(x, y, x + w, y + totalH, 0xEC11151E);
        context.fill(x + 1, y + 1, x + w - 1, y + headerH, 0xFF0B0E15);
        context.drawStrokedRectangle(x, y, w, totalH, 0xFFD8E6F2);

        context.drawCenteredTextWithShadow(
                this.textRenderer,
                Text.literal("§b§l" + title),
                x + w / 2,
                y + 5,
                0xFF67E8F9
        );

        int curY = y + headerH;
        for (MenuRow row : rows) {
            boolean hovered = mouseX >= x && mouseX <= x + w && mouseY >= curY && mouseY < curY + rowH;
            boolean isToggle = row.stateSupplier() != null;
            boolean isOn = isToggle && row.stateSupplier().getAsBoolean();

            if (hovered) {
                context.fill(x + 1, curY, x + w - 1, curY + rowH, 0x3338BDF8);
            }

            context.fill(x + 4, curY + rowH - 1, x + w - 4, curY + rowH, 0x22FFFFFF);

            if (isOn) {
                context.fill(x + 1, curY + 2, x + 4, curY + rowH - 2, 0xFF3B82F6);
            }

            int textColor = isOn ? 0xFF60A5FA : (hovered ? 0xFFFFFFFF : 0xFFE2E8F0);
            context.drawTextWithShadow(
                    this.textRenderer,
                    Text.literal(row.label()),
                    x + 7,
                    curY + 6,
                    textColor
            );

            if (isToggle) {
                renderPillToggleSwitch(context, x + w - 27, curY + 5, isOn);
            } else if (row.valueBadge() != null) {
                int badgeW = this.textRenderer.getWidth(row.valueBadge()) + 8;
                int badgeX = x + w - badgeW - 5;
                int badgeY = curY + 4;
                context.fill(badgeX, badgeY, badgeX + badgeW, badgeY + 11, 0xFF1E293B);
                context.drawStrokedRectangle(badgeX, badgeY, badgeW, 11, 0xFF38BDF8);
                context.drawTextWithShadow(
                        this.textRenderer,
                        Text.literal(row.valueBadge()),
                        badgeX + 4,
                        badgeY + 2,
                        0xFF7DD3FC
                );
            }

            activeHitboxes.add(new ClickHitbox(x, curY, w, rowH, row.onLeftClick(), row.onRightClick()));
            curY += rowH;
        }
    }

    private void renderPillToggleSwitch(DrawContext context, int sx, int sy, boolean isOn) {
        int sw = 21;
        int sh = 9;
        int trackColor = isOn ? 0xFF2563EB : 0xFF272B36;
        int borderColor = isOn ? 0xFF60A5FA : 0xFF475569;

        context.fill(sx + 1, sy, sx + sw - 1, sy + sh, trackColor);
        context.fill(sx, sy + 1, sx + sw, sy + sh - 1, trackColor);
        context.drawStrokedRectangle(sx, sy, sw, sh, borderColor);

        int knobX = isOn ? (sx + sw - 8) : (sx + 2);
        int knobColor = isOn ? 0xFF93C5FD : 0xFFF8FAFC;
        context.fill(knobX, sy + 2, knobX + 6, sy + sh - 2, knobColor);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (this.youtubeLinkField != null && this.youtubeLinkField.mouseClicked(click, doubled)) {
            this.setFocused(this.youtubeLinkField);
            return true;
        }
        double mx = click.x();
        double my = click.y();
        int button = click.button();

        for (ClickHitbox box : activeHitboxes) {
            if (mx >= box.x() && mx <= box.x() + box.w() && my >= box.y() && my <= box.y() + box.h()) {
                if (button == 1 && box.onRightClick() != null) {
                    box.onRightClick().run();
                    return true;
                } else if (box.onLeftClick() != null) {
                    box.onLeftClick().run();
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (this.youtubeLinkField != null && this.youtubeLinkField.isFocused()) {
            if (this.youtubeLinkField.keyPressed(input)) {
                return true;
            }
        }
        return super.keyPressed(input);
    }

    @Override
    public void close() {
        if (this.youtubeLinkField != null && !this.youtubeLinkField.getText().isBlank()) {
            config.youtubeLink = this.youtubeLinkField.getText().trim();
        }
        config.save();
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
