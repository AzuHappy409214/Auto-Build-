package net.autobuild.litematica;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.KeybindsScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/**
 * Menu 3 Cột Như Cũ (AutoBuildMenuScreen v2.5) dùng các nút bấm & thanh trượt chuẩn của Minecraft:
 * - Cột Trái: AutoBuild, Khóa Tầng, Block Kê, Tự Dừng Khi Hết Vật Liệu, Bộ Lọc Whitelist/Blacklist,
 *   Auto /home khi kẹt, và Thanh Trượt (SliderWidget) chỉnh tốc độ xoay góc nhìn mượt.
 * - Cột Giữa: Gắn Phím Tắt trực tiếp (Click-to-Bind) + Lưu/Tải nhanh nhiều Profile ("DonutSMP An Toàn", "Creative Nhanh", "Survival Chậm", "Custom").
 * - Cột Phải: Xem Mô Hình 3D bằng BLOCK THẬT + Điều khiển Nhạc (.mp3/.wav & YouTube).
 */
public class AutoBuildMenuScreen extends Screen {

    private final Screen parent;
    private final PrinterConfig config;
    private final SchematicAnalyzer analyzer;
    private final PlacementEngine placementEngine;
    private final SmartPathfinder pathfinder;
    private final MusicManager musicManager;
    private final List<KeyBinding> modKeyBindings;

    private TextFieldWidget youtubeLinkField;
    private KeyBinding waitingForKeybind = null;
    private int previewRotationIndex = 0;
    private Integer previewFilterY = null;
    private float previewZoom = 1.0f;
    private boolean hideBuiltIn3D = false;

    /**
     * Thanh trượt chuẩn của Minecraft (SliderWidget) chỉnh tốc độ xoay góc nhìn từ 10°/tick đến 180°/tick.
     */
    private class RotationSpeedSlider extends SliderWidget {
        public RotationSpeedSlider(int x, int y, int width, int height, float currentDegreesPerTick) {
            super(x, y, width, height, Text.empty(), MathHelper.clamp((currentDegreesPerTick - 10.0) / 170.0, 0.0, 1.0));
            this.updateMessage();
        }

        @Override
        protected void updateMessage() {
            int deg = Math.round(config.maxRotationStep);
            String tag;
            if (deg <= 32) {
                tag = "§aSiêu mượt";
            } else if (deg <= 70) {
                tag = "§eChuẩn DonutSMP";
            } else if (deg <= 130) {
                tag = "§bNhanh";
            } else {
                tag = "§dTức thời";
            }
            this.setMessage(Text.literal("Xoay: §f" + deg + "°/t §7(" + tag + "§7)"));
        }

        @Override
        protected void applyValue() {
            float deg = (float) (10.0 + this.value * 170.0);
            config.maxRotationStep = Math.round(deg);
            config.save();
        }
    }

    public AutoBuildMenuScreen(
            Screen parent,
            PrinterConfig config,
            SchematicAnalyzer analyzer,
            PlacementEngine placementEngine,
            SmartPathfinder pathfinder,
            MusicManager musicManager,
            List<KeyBinding> modKeyBindings
    ) {
        super(Text.literal("Litematica AutoBuild v2.5 - Menu Cấu Hình & Mô Hình 3D"));
        this.parent = parent;
        this.config = config;
        this.analyzer = analyzer;
        this.placementEngine = placementEngine;
        this.pathfinder = pathfinder;
        this.musicManager = musicManager;
        this.modKeyBindings = modKeyBindings;
    }

    @Override
    protected void init() {
        super.init();
        if (this.client != null) {
            World schemWorld = LitematicaBridge.getSchematicWorld();
            analyzer.updateAnalysis(this.client, schemWorld, config, new InventoryManager(), true);
        }

        int leftX = 10;
        int centerColX = 172;
        int rightColX = 326;
        int btnW = 156;
        int btnH = 17;
        int startY = 28;
        int gapY = 18;

        // ================= CỘT TRÁI: TÍNH NĂNG, BỘ LỌC BLOCK & SLIDER XOAY MƯỢT =================
        this.addDrawableChild(ButtonWidget.builder(getPrinterButtonText(), btn -> {
            config.printerEnabled = !config.printerEnabled;
            config.save();
            musicManager.onMusicSettingChanged(this.client, config, false);
            btn.setMessage(getPrinterButtonText());
        }).dimensions(leftX, startY, btnW, btnH).build());

        this.addDrawableChild(ButtonWidget.builder(getModeButtonText(), btn -> {
            config.antiCheatStrictMode = !config.antiCheatStrictMode;
            config.save();
            btn.setMessage(getModeButtonText());
        }).dimensions(leftX, startY + gapY, btnW, btnH).build());

        this.addDrawableChild(ButtonWidget.builder(getLayerLockButtonText(), btn -> {
            config.strictLayerByLayer = !config.strictLayerByLayer;
            config.save();
            btn.setMessage(getLayerLockButtonText());
        }).dimensions(leftX, startY + gapY * 2, btnW, btnH).build());

        this.addDrawableChild(ButtonWidget.builder(getScaffoldButtonText(), btn -> {
            config.autoScaffoldEnabled = !config.autoScaffoldEnabled;
            config.save();
            btn.setMessage(getScaffoldButtonText());
        }).dimensions(leftX, startY + gapY * 3, btnW, btnH).build());

        // Tính năng 1: Tự động dừng khi hết vật liệu
        this.addDrawableChild(ButtonWidget.builder(getOutOfMatStopButtonText(), btn -> {
            config.autoStopWhenOutOfMaterials = !config.autoStopWhenOutOfMaterials;
            config.save();
            btn.setMessage(getOutOfMatStopButtonText());
        }).dimensions(leftX, startY + gapY * 4, btnW, btnH).build());

        // Tính năng 2: Mở màn hình Whitelist / Blacklist Block
        this.addDrawableChild(ButtonWidget.builder(getBlockFilterButtonText(), btn -> {
            if (this.client != null) {
                this.client.setScreen(new BlockFilterScreen(this, config, analyzer));
            }
        }).dimensions(leftX, startY + gapY * 5, btnW, btnH).build());

        this.addDrawableChild(ButtonWidget.builder(getAutoWalkButtonText(), btn -> {
            config.autoWalkEnabled = !config.autoWalkEnabled;
            config.save();
            btn.setMessage(getAutoWalkButtonText());
        }).dimensions(leftX, startY + gapY * 6, btnW - 52, btnH).build());

        this.addDrawableChild(ButtonWidget.builder(getExcavateShortText(), btn -> {
            config.autoExcavateWrongBlocks = !config.autoExcavateWrongBlocks;
            config.save();
            btn.setMessage(getExcavateShortText());
        }).dimensions(leftX + btnW - 50, startY + gapY * 6, 50, btnH).build());

        this.addDrawableChild(ButtonWidget.builder(getAutoHomeToggleText(), btn -> {
            config.autoHomeWhenStuck = !config.autoHomeWhenStuck;
            config.save();
            btn.setMessage(getAutoHomeToggleText());
        }).dimensions(leftX, startY + gapY * 7, btnW - 52, btnH).build());

        this.addDrawableChild(ButtonWidget.builder(getHomeNumButtonText(), btn -> {
            config.stuckHomeNumber = (config.stuckHomeNumber % 15) + 1;
            config.save();
            btn.setMessage(getHomeNumButtonText());
        }).dimensions(leftX + btnW - 50, startY + gapY * 7, 50, btnH).build());

        // Tính năng 3: Thanh trượt (SliderWidget) chỉnh tốc độ xoay góc nhìn mượt
        this.addDrawableChild(new RotationSpeedSlider(leftX, startY + gapY * 8, btnW, btnH, config.maxRotationStep));

        this.addDrawableChild(ButtonWidget.builder(getDelayButtonText(), btn -> {
            config.placeDelayTicks = (config.placeDelayTicks % 5) + 1;
            config.save();
            btn.setMessage(getDelayButtonText());
        }).dimensions(leftX, startY + gapY * 9, btnW / 2 - 2, btnH).build());

        this.addDrawableChild(ButtonWidget.builder(getReachButtonText(), btn -> {
            double nextReach = config.maxReachDistance + 0.25;
            if (nextReach > 5.0) {
                nextReach = 3.75;
            }
            config.maxReachDistance = Math.round(nextReach * 100.0) / 100.0;
            config.save();
            btn.setMessage(getReachButtonText());
        }).dimensions(leftX + btnW / 2 + 2, startY + gapY * 9, btnW / 2 - 2, btnH).build());

        // ================= CỘT GIỮA: GẮN PHÍM & QUẢN LÝ NHIỀU PROFILE =================
        int keyBtnW = 148;
        for (int i = 0; i < modKeyBindings.size(); i++) {
            KeyBinding kb = modKeyBindings.get(i);
            this.addDrawableChild(ButtonWidget.builder(getKeybindButtonText(kb), btn -> {
                this.waitingForKeybind = kb;
                this.clearAndInit();
            }).dimensions(centerColX, startY + i * gapY, keyBtnW, btnH).build());
        }

        // Tính năng 4: Nút Đổi Nhanh Profile ("DonutSMP An Toàn", "Creative Nhanh", "Survival Chậm", "Custom 1/2")
        this.addDrawableChild(ButtonWidget.builder(getProfileButtonText(), btn -> {
            ProfileManager.cycleAndLoadNextProfile(this.client, config);
            this.clearAndInit();
        }).dimensions(centerColX, startY + 9 * gapY, keyBtnW - 44, btnH).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("§aLưu"), btn -> {
            String targetSlot = config.activeProfileName.startsWith("Custom") ? config.activeProfileName : "Custom 1";
            ProfileManager.saveCurrentToCustomProfile(this.client, config, targetSlot);
            this.clearAndInit();
        }).dimensions(centerColX + keyBtnW - 42, startY + 9 * gapY, 42, btnH).build());

        // ================= CỘT PHẢI: MÔ HÌNH BLOCK 3D THẬT & NHẠC =================
        int rightW = Math.max(196, this.width - rightColX - 10);
        int previewControlY = startY + 108;

        int thirdW = (rightW - 8) / 3;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Xoay: " + (previewRotationIndex * 90) + "°"), btn -> {
            previewRotationIndex = (previewRotationIndex + 1) % 4;
            btn.setMessage(Text.literal("Xoay: " + (previewRotationIndex * 90) + "°"));
        }).dimensions(rightColX, previewControlY, thirdW, btnH).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Zoom: " + String.format("%.1fx", previewZoom)), btn -> {
            previewZoom += 0.25f;
            if (previewZoom > 1.75f) previewZoom = 0.75f;
            btn.setMessage(Text.literal("Zoom: " + String.format("%.1fx", previewZoom)));
        }).dimensions(rightColX + thirdW + 4, previewControlY, thirdW, btnH).build());

        this.addDrawableChild(ButtonWidget.builder(getLayerFilterButtonText(), btn -> {
            if (previewFilterY == null) {
                previewFilterY = (analyzer.getActiveLayerY() != null)
                        ? analyzer.getActiveLayerY()
                        : analyzer.getMinSchematicY();
            } else if (previewFilterY < analyzer.getMaxSchematicY()) {
                previewFilterY++;
            } else {
                previewFilterY = null;
            }
            btn.setMessage(getLayerFilterButtonText());
        }).dimensions(rightColX + (thirdW + 4) * 2, previewControlY, rightW - (thirdW + 4) * 2, btnH).build());

        int musicRow1Y = previewControlY + gapY + 10;
        int pasteBtnW = 64;
        int fieldW = Math.max(100, rightW - pasteBtnW - 4);

        this.youtubeLinkField = new TextFieldWidget(
                this.textRenderer,
                rightColX,
                musicRow1Y,
                fieldW,
                btnH,
                Text.literal("Link YouTube / Playlist")
        );
        this.youtubeLinkField.setMaxLength(512);
        this.youtubeLinkField.setText(config.youtubeLink != null ? config.youtubeLink : "");
        this.youtubeLinkField.setChangedListener(val -> {
            config.youtubeLink = val.trim();
        });
        this.addDrawableChild(this.youtubeLinkField);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("§bDán Link"), btn -> {
            if (this.client != null && this.client.keyboard != null) {
                String clip = this.client.keyboard.getClipboard();
                if (clip != null && !clip.isBlank()) {
                    String trimmed = clip.trim();
                    this.youtubeLinkField.setText(trimmed);
                    config.youtubeLink = trimmed;
                    config.save();
                }
            }
        }).dimensions(rightColX + fieldW + 4, musicRow1Y, pasteBtnW, btnH).build());

        int musicRow2Y = musicRow1Y + gapY;
        this.addDrawableChild(ButtonWidget.builder(getMusicToggleButtonText(), btn -> {
            if (this.youtubeLinkField != null && !this.youtubeLinkField.getText().isBlank()) {
                config.youtubeLink = this.youtubeLinkField.getText().trim();
            }
            config.musicEnabled = !config.musicEnabled;
            config.save();
            musicManager.onMusicSettingChanged(this.client, config, true);
            btn.setMessage(getMusicToggleButtonText());
        }).dimensions(rightColX, musicRow2Y, rightW / 2 - 2, btnH).build());

        this.addDrawableChild(ButtonWidget.builder(getMusicSourceButtonText(), btn -> {
            config.useLocalMusicFolder = !config.useLocalMusicFolder;
            config.save();
            if (config.printerEnabled && config.musicEnabled) {
                musicManager.onMusicSettingChanged(this.client, config, true);
            }
            btn.setMessage(getMusicSourceButtonText());
        }).dimensions(rightColX + rightW / 2 + 2, musicRow2Y, rightW / 2 - 2, btnH).build());

        int musicRow3Y = musicRow2Y + gapY;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§d♪ Phát / Bài Tiếp"), btn -> {
            if (this.youtubeLinkField != null && !this.youtubeLinkField.getText().isBlank()) {
                config.youtubeLink = this.youtubeLinkField.getText().trim();
            }
            config.save();
            musicManager.skipToNextLocalTrack(this.client, config);
        }).dimensions(rightColX, musicRow3Y, thirdW, btnH).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("§c■ Dừng Nhạc"), btn -> {
            musicManager.stopActiveAudio();
        }).dimensions(rightColX + thirdW + 4, musicRow3Y, thirdW, btnH).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("§eMở Folder"), btn -> {
            musicManager.openMusicFolder();
        }).dimensions(rightColX + (thirdW + 4) * 2, musicRow3Y, rightW - (thirdW + 4) * 2, btnH).build());

        // Hàng nút dưới cùng: Bảng Phím Minecraft, Đổi Kiểu Menu & Đóng
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§eBảng Phím MC..."), btn -> {
            if (this.client != null) {
                this.client.setScreen(new KeybindsScreen(this, this.client.options));
            }
        }).dimensions(this.width / 2 - 205, this.height - 20, 120, 17).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("§7Menu Công Tắc Gạt"), btn -> {
            config.menuStyle = "MODERN";
            config.save();
            if (this.client != null) {
                this.client.setScreen(new ModernToggleMenuScreen(
                        parent, config, analyzer, placementEngine, pathfinder, musicManager, modKeyBindings
                ));
            }
        }).dimensions(this.width / 2 - 80, this.height - 20, 130, 17).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("§aĐóng & Lưu"), btn -> this.close())
                .dimensions(this.width / 2 + 55, this.height - 20, 150, 17).build());
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (waitingForKeybind != null) {
            if (input.key() == GLFW.GLFW_KEY_ESCAPE) {
                waitingForKeybind.setBoundKey(InputUtil.UNKNOWN_KEY);
            } else {
                waitingForKeybind.setBoundKey(InputUtil.Type.KEYSYM.createFromCode(input.key()));
            }
            KeyBinding.updateKeysByCode();
            if (this.client != null && this.client.options != null) {
                this.client.options.write();
            }
            waitingForKeybind = null;
            this.clearAndInit();
            return true;
        }
        if (this.youtubeLinkField != null && this.youtubeLinkField.isFocused()) {
            if (this.youtubeLinkField.keyPressed(input)) {
                return true;
            }
        }
        return super.keyPressed(input);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        context.fill(0, 0, this.width, this.height, 0xCC0B0E14);
        super.render(context, mouseX, mouseY, deltaTicks);

        context.drawCenteredTextWithShadow(
                this.textRenderer,
                Text.literal("§b§lLITEMATICA AUTOBUILD v2.5 §7— §fProfile: §e" + config.activeProfileName + " §7| §aSourceGuard Active"),
                this.width / 2,
                6,
                0xFFFFFFFF
        );

        context.drawTextWithShadow(this.textRenderer, Text.literal("§e§l1. Tính Năng, Lọc & Xoay"), 10, 17, 0xFFFFFFFF);
        context.drawTextWithShadow(this.textRenderer, Text.literal("§e§l2. Phím Tắt & Profile"), 172, 17, 0xFFFFFFFF);
        context.drawTextWithShadow(this.textRenderer, Text.literal("§e§l3. Mô Hình Block 3D Bản Vẽ"), 326, 17, 0xFFFFFFFF);

        int rightW = Math.max(196, this.width - 326 - 10);
        SchematicPreviewRenderer.renderRealBlock3DPreview(
                context,
                this.textRenderer,
                analyzer,
                placementEngine,
                326,
                28,
                rightW,
                104,
                previewRotationIndex,
                previewFilterY,
                previewZoom,
                hideBuiltIn3D
        );

        int musicLabelY = 28 + 108 + 19;
        int localTrackCount = musicManager.listLocalMusicFiles().size();
        context.drawTextWithShadow(
                this.textRenderer,
                Text.literal("§d§l4. Nhạc (.mp3/.wav: " + localTrackCount + " bài | Đang phát: §f" + musicManager.getCurrentTrackLabel() + "§d§l):"),
                326,
                musicLabelY,
                0xFFFFFFFF
        );
    }

    private Text getPrinterButtonText() {
        return Text.literal("AutoBuild: " + (config.printerEnabled ? "§aBẬT" : "§cTẮT"));
    }

    private Text getModeButtonText() {
        return Text.literal("Chế độ: " + (config.antiCheatStrictMode ? "§eDonutSMP" : "§bEasyPlace"));
    }

    private Text getLayerLockButtonText() {
        return Text.literal("Khóa Chặt Tầng Y: " + (config.strictLayerByLayer ? "§aBẬT" : "§cTẮT"));
    }

    private Text getScaffoldButtonText() {
        return Text.literal("Tự Đặt Block Kê: " + (config.autoScaffoldEnabled ? "§aBẬT" : "§cTẮT"));
    }

    private Text getOutOfMatStopButtonText() {
        return Text.literal("Hết Vật Liệu -> Dừng: " + (config.autoStopWhenOutOfMaterials ? "§aBẬT" : "§cTẮT"));
    }

    private Text getBlockFilterButtonText() {
        int count = "WHITELIST".equalsIgnoreCase(config.blockFilterMode)
                ? config.whitelistedBlocks.size()
                : config.blacklistedBlocks.size();
        return Text.literal("§bLọc Block (" + config.blockFilterMode + ": " + count + ")...");
    }

    private Text getAutoWalkButtonText() {
        return Text.literal("Đi Bộ A*: " + (config.autoWalkEnabled ? "§aBẬT" : "§cTẮT"));
    }

    private Text getExcavateShortText() {
        return Text.literal("Phá: " + (config.autoExcavateWrongBlocks ? "§aBẬT" : "§cTẮT"));
    }

    private Text getAutoHomeToggleText() {
        return Text.literal("Kẹt -> /home: " + (config.autoHomeWhenStuck ? "§aBẬT" : "§cTẮT"));
    }

    private Text getHomeNumButtonText() {
        return Text.literal("§6/home " + config.stuckHomeNumber);
    }

    private Text getDelayButtonText() {
        return Text.literal("Delay: §e" + config.placeDelayTicks + "t");
    }

    private Text getReachButtonText() {
        return Text.literal("Tầm: §b" + config.maxReachDistance + "m");
    }

    private Text getProfileButtonText() {
        return Text.literal("§6Profile: §f" + config.activeProfileName);
    }

    private Text getLayerFilterButtonText() {
        return Text.literal("Tầng: " + (previewFilterY == null ? "§aTất Cả" : ("§eY=" + previewFilterY)));
    }

    private Text getMusicToggleButtonText() {
        return Text.literal("Nhạc: " + (config.musicEnabled ? "§aBẬT" : "§cTẮT"));
    }

    private Text getMusicSourceButtonText() {
        return Text.literal("Nguồn: " + (config.useLocalMusicFolder ? "§aMP3/WAV Local" : "§cYouTube"));
    }

    private Text getKeybindButtonText(KeyBinding kb) {
        String shortLabel = shortenKeybindName(kb.getId());
        if (waitingForKeybind == kb) {
            return Text.literal("§e> Nhấn phím... <");
        }
        return Text.literal(shortLabel + ": §b[" + kb.getBoundKeyLocalizedText().getString() + "]");
    }

    private String shortenKeybindName(String id) {
        if (id.endsWith(".toggle")) return "Bật/Tắt Mod";
        if (id.endsWith(".menu")) return "Mở Menu 3D";
        if (id.endsWith(".mode")) return "Đổi Chế Độ";
        if (id.endsWith(".layer_lock")) return "Khóa Tầng";
        if (id.endsWith(".scaffold")) return "Đặt Block Kê";
        if (id.endsWith(".excavate")) return "Phá Block Sai";
        if (id.endsWith(".autowalk")) return "Tự Đi Bộ A*";
        if (id.endsWith(".delay")) return "Đổi Tốc Độ";
        if (id.endsWith(".music")) return "Bật/Tắt Nhạc";
        return id;
    }

    @Override
    public void close() {
        if (this.youtubeLinkField != null && !this.youtubeLinkField.getText().isBlank()) {
            config.youtubeLink = this.youtubeLinkField.getText().trim();
        }
        config.save();
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
